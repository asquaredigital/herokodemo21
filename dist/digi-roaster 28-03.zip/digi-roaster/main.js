(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/app.component.html":
/*!**************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/app.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ngx-spinner\r\nbdOpacity = 0.1\r\nbdColor = \"rgba(51,51,51,0.09)\"\r\nsize = \"medium\"\r\ncolor = \"#cdc2c2\"\r\ntype = \"ball-spin-clockwise\"\r\n[fullScreen] = \"true\"\r\n>\r\n<!-- <p style=\"color: white\" > Loading... </p> -->\r\n</ngx-spinner>\r\n\r\n<router-outlet ></router-outlet>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/customer/customer.component.html":
/*!****************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/customer/customer.component.html ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<mat-toolbar  class=\"mat-elevation-z6\" color=\"primary\">\r\n    <button mat-icon-button (click)=\"opened = !opened\">\r\n      <mat-icon  title=\"Menu\">menu</mat-icon>\r\n      </button> Digi Roster\r\n      <span class=\"example-spacer\"></span>\r\n      <button (click)=\"logout();\" mat-icon-button class=\"example-icon favorite-icon\" aria-label=\"Example icon-button with heart icon\">\r\n        <mat-icon title=\"Logout\">logout</mat-icon>\r\n      </button>\r\n  </mat-toolbar>\r\n  <mat-sidenav-container class=\"main-sidenav-container\" (backdropClick)=\"opened = !opened\">\r\n  <mat-sidenav [mode]=\"mode\"\r\n              [opened]=\"opened\"\r\n              [fixedInViewport]=\"true\"\r\n              [fixedTopGap]=\"layoutGap\">\r\n              <app-sidebar></app-sidebar>\r\n    </mat-sidenav>\r\n    <router-outlet></router-outlet>   \r\n  </mat-sidenav-container>\r\n   "

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/customer/layouts/footer/footer.component.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/customer/layouts/footer/footer.component.html ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<p>\r\n  footer works!\r\n</p>\r\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/customer/layouts/header/header.component.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/customer/layouts/header/header.component.html ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<mat-toolbar>\r\n  <button  mat-icon-button class=\"example-icon\" aria-label=\"Example icon-button with menu icon\">\r\n   <mat-icon>menu</mat-icon>\r\n </button>\r\n\r\n</mat-toolbar>\r\n\r\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/customer/layouts/sidebar/sidebar.component.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/customer/layouts/sidebar/sidebar.component.html ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"logo\">\r\n        <a href=\"#\" class=\"simple-text\">\r\n            <div class=\"logo-img\">\r\n            </div>\r\n        </a>\r\n    </div>\r\n    <div class=\"sidebar-wrapper\">  \r\n            <mat-nav-list>\r\n                    <a class=\"nav-link\" *ngFor=\"let menuItem of menuItems\"\r\n                    [routerLinkActive]=\"['active']\"\r\n                       mat-list-item  \r\n                       [routerLink]=\"menuItem.path\" \r\n                    > \r\n                       <p>{{menuItem.title}}</p>\r\n                       </a>\r\n                  </mat-nav-list>         \r\n     \r\n       \r\n    </div>\r\n    "

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/forgot-password/forgot-password.component.html":
/*!******************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/forgot-password/forgot-password.component.html ***!
  \******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"justify-content-center row\">\r\n<div class=\"col-lg-3\">\r\n<div class=\"card\">\r\n  <div class=\"card-header\">\r\n    Logo : Digi Roster\r\n  </div>\r\n  <div class=\"p-4 position-relative card-body\">\r\n    <div >\r\n      <h4 class=\"pageheading\">Forgot Password</h4>\r\n    </div>\r\n    <form   >\r\n      <div class=\"form-group\">\r\n      \t<span></span>\r\n        <input autocomplete=\"off\" formControlName=\"user_name\" name=\"username\" placeholder=\"Enter your username\" required=\"\" id=\"username\" type=\"text\" class=\"is-touched is-pristine av-valid form-control\" >\r\n         \r\n        </div>          \r\n          <div class=\"form-group\">\r\n            <button  type=\"submit\" class=\"btn btn-success\">Send Email</button>\r\n          </div>\r\n         \r\n        </form>\r\n      </div>\r\n    </div>\r\n\r\n  </div>\r\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/login/login.component.html":
/*!**********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/login/login.component.html ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- <div class=\"container\">\r\n\r\n  <form  [formGroup]=\"loginForm\" (ngSubmit)=\"login()\"  class=\"login-form\">\r\n  <div class=\"login-logo\"></div>\r\n  <div class=\"login-head\">\r\n     <h3>LOGIN</h3>\r\n  </div>\r\n  <div [ngClass]=\"{ 'has-error': isSubmitted && formControls.user_name.errors }\">\r\n     <input    class=\"form-control mb-4\" type=\"email\" placeholder=\"Email\" formControlName=\"user_name\">\r\n  </div>\r\n  <div *ngIf=\"isSubmitted && formControls.user_name.errors\" class=\"help-block\">\r\n     <div *ngIf=\"formControls.user_name.errors.required\"><span class=\"error-span\">Email is required</span></div>\r\n     <div *ngIf=\"formControls.user_name.errors.email\"><span class=\"error-span\">Email must be a valid email address</span></div>\r\n  </div>\r\n  <div class=\"login-password\" [ngClass]=\"{ 'has-error': isSubmitted && formControls.password.errors }\">\r\n     <input  class=\"form-control mb-4\"  type=\"password\" placeholder=\"Password\" formControlName=\"password\">\r\n  </div>\r\n  <div *ngIf=\"isSubmitted && formControls.password.errors\" class=\"help-block\">\r\n     <div *ngIf=\"formControls.password.errors.required\"><span class=\"error-span\" >Password is required</span></div>\r\n  </div>\r\n  <span class=\"error-span\" >{{error}}</span>\r\n  <div class=\"remember-loginbutton\">\r\n     <div>\r\n        <label class=\"remember\">\r\n          <span class=\"check-border\">\r\n            <input class=\"remember-check\"  formControlName=\"remember_me\"  type=\"checkbox\" value=\"\">\r\n          </span><span class=\"remember-txt\">Remember me</span>\r\n        </label>\r\n        <button  [disabled]=\"isDisabled\"  type=\"submit\" class=\"login-button pull-right\">Login</button>\r\n     </div>\r\n  </div>\r\n  </form>\r\n</div> -->\r\n\r\n<!--     <div class = \"container\">\r\n  <div class=\"wrapper\">\r\n    <form  [formGroup]=\"loginForm\" (ngSubmit)=\"login()\"  class=\"form-signin\">       \r\n        <h3 class=\"form-signin-heading\">Welcome Back! Please Sign In</h3>\r\n        <div [ngClass]=\"{ 'has-error': isSubmitted && formControls.user_name.errors }\">\r\n     <input    class=\"form-control\" type=\"email\" placeholder=\"Email\" formControlName=\"user_name\">\r\n  </div>\r\n  <div *ngIf=\"isSubmitted && formControls.user_name.errors\" class=\"help-block\">\r\n     <div *ngIf=\"formControls.user_name.errors.required\"><span class=\"error-span\">Email is required</span></div>\r\n     <div *ngIf=\"formControls.user_name.errors.email\"><span class=\"error-span\">Email must be a valid email address</span></div>\r\n  </div>\r\n  <div class=\"login-password\" [ngClass]=\"{ 'has-error': isSubmitted && formControls.password.errors }\">\r\n     <input  class=\"form-control\"  type=\"password\" placeholder=\"Password\" formControlName=\"password\">\r\n  </div>\r\n  <div *ngIf=\"isSubmitted && formControls.password.errors\" class=\"help-block\">\r\n     <div *ngIf=\"formControls.password.errors.required\"><span class=\"error-span\" >Password is required</span></div>\r\n  </div>       \r\n        <button  [disabled]=\"isDisabled\"  type=\"submit\" class=\"login-button\">Login</button>     \r\n    </form>     \r\n  </div>\r\n</div> -->\r\n\r\n\r\n<div class=\"justify-content-center row\">\r\n<div class=\"col-lg-3\">\r\n<div class=\"card\">\r\n  <div class=\"card-header\">\r\n    Digi Roster\r\n  </div>\r\n  <div class=\"p-4 position-relative card-body\">\r\n    <div >\r\n      <h4 class=\"pageheading\">Sign In</h4>\r\n    \r\n    </div>\r\n    <form   [formGroup]=\"loginForm\" (ngSubmit)=\"login()\" >\r\n      <div class=\"form-group\">\r\n        <label for=\"username\" class=\"\">Username</label>\r\n        <input autocomplete=\"off\" formControlName=\"user_name\" name=\"username\" placeholder=\"Enter your username\" required=\"\" id=\"username\" type=\"text\" class=\"is-touched is-pristine av-valid form-control\" >\r\n         <div *ngIf=\"isSubmitted && formControls.user_name.errors\" class=\"help-block\">\r\n     <div *ngIf=\"formControls.user_name.errors.required\"><span class=\"error-span\">Email is required</span></div>\r\n     <div *ngIf=\"formControls.user_name.errors.email\"><span class=\"error-span\">Email must be a valid email address</span></div>\r\n  </div>\r\n        </div>\r\n      \r\n        <div class=\"form-group\">\r\n          <label for=\"password\" class=\"\">Password</label>\r\n          <a class=\"text-muted float-right\" href=\"/#/forgot-password\">\r\n            <small>Forgot your password?</small>\r\n          </a>\r\n          <input formControlName=\"password\" autocomplete=\"off\" name=\"password\" placeholder=\"Enter your password\" required=\"\" id=\"password\" type=\"password\" class=\"is-untouched is-pristine av-valid form-control\">\r\n           <div *ngIf=\"isSubmitted && formControls.password.errors\" class=\"help-block\">\r\n     <div *ngIf=\"formControls.password.errors.required\"><span class=\"error-span\" >Password is required</span></div>\r\n  </div> \r\n          </div>\r\n          \r\n          <div class=\"form-group\">\r\n            <button  [disabled]=\"isDisabled\"  type=\"submit\" class=\"btn btn-success\">Submit</button>\r\n          </div>\r\n         \r\n        </form>\r\n      </div>\r\n    </div>\r\n\r\n  </div>\r\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/shared-components/calender/calendar.component.html":
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/shared-components/calender/calendar.component.html ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/shared-components/child/child.component.html":
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/shared-components/child/child.component.html ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<p>Shared child works!</p>\r\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/shared-components/profile/profile.component.html":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/shared-components/profile/profile.component.html ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"content-page\" style=\"margin-left:0px\">\r\n    <div class=\"content\">\r\n        <!-- Topbar Start -->\r\n       \r\n        <!-- end Topbar -->\r\n\r\n        <!-- Start Content-->\r\n        <div class=\"container-fluid\">\r\n            \r\n            <!-- start page title -->\r\n             \r\n            <!-- end page title --> \r\n            \r\n            <select name=\"group\">\r\n                <option value=\"\" selected>Select Group</option>\r\n                <option value=\"group1\">Group 1</option>\r\n                <option value=\"group2\">Group 2</option>\r\n                <option value=\"group3\">Group 3</option>\r\n                <option value=\"group4\">Group 4</option>\r\n\r\n\r\n            </select>\r\n\r\n            <select name=\"name\">\r\n                <option value=\"\" selected>Select Carer </option>\r\n\r\n                <option value=\"carer1\">Carer 1</option>\r\n                <option value=\"carer2\">Carer 2</option>\r\n                <option value=\"carer3\">Carer 3</option>\r\n                <option value=\"carer4\">Carer 4</option>\r\n\r\n            </select>\r\n            <div style=\"height: 30px;\">\r\n\r\n            </div>\r\n            \r\n            <div class=\"row\">\r\n                <div class=\"col-sm-12\">\r\n                    <!-- Profile -->\r\n                    \r\n                    <div class=\"card bg-primary\">\r\n                       \r\n                        <div class=\"card-body profile-user-box\">\r\n                            \r\n                            <div class=\"row\">\r\n                                <div class=\"col-sm-8\">\r\n                                    <div class=\"media\">\r\n                                        <span class=\"float-left m-2 mr-4\"><img src=\"assets/images/users/avatar-2.jpg\" style=\"height: 100px;\" alt=\"\" class=\"rounded-circle img-thumbnail\"></span>\r\n                                        <div class=\"media-body\">\r\n\r\n                                            <h4 class=\"mt-1 mb-1 text-white\">Michael Franklin</h4>\r\n                                            <p class=\"font-13 text-white-50\"> Active Carer</p>\r\n\r\n                                            <ul class=\"mb-0 list-inline text-light\">\r\n                                                <li class=\"list-inline-item mr-3\">\r\n                                                    <h5 class=\"mb-1\">251</h5>\r\n                                                    <p class=\"mb-0 font-13 text-white-50\">Total Appointments</p>\r\n                                                </li>\r\n                                                <li class=\"list-inline-item\">\r\n                                                    <h5 class=\"mb-1\">5482</h5>\r\n                                                    <p class=\"mb-0 font-13 text-white-50\">Total Hours</p>\r\n                                                </li>\r\n                                            </ul>\r\n                                        </div> <!-- end media-body-->\r\n                                    </div>\r\n                                </div> <!-- end col-->\r\n\r\n                                <div class=\"col-sm-4\">\r\n                                    <div class=\"text-center mt-sm-0 mt-3 text-sm-right\">\r\n                                        <button type=\"button\" class=\"btn btn-light\">\r\n                                            <i class=\"mdi mdi-account-edit mr-1\"></i> Edit Profile\r\n                                        </button>\r\n                                    </div>\r\n                                </div> <!-- end col-->\r\n                            </div> <!-- end row -->\r\n\r\n                        </div> <!-- end card-body/ profile-user-box-->\r\n                    </div><!--end profile/ card -->\r\n                </div> <!-- end col-->\r\n            </div>\r\n            <!-- end row -->\r\n\r\n\r\n            <div class=\"row\">\r\n                <div class=\"col-lg-4\">\r\n                    <!-- Personal-Information -->\r\n                    <div class=\"card\">\r\n                        <div class=\"card-body\">\r\n                            <h4 class=\"header-title mt-0 mb-3\">User Information</h4>\r\n                            <p class=\"text-muted font-13\">\r\n                                Hye, I’m Michael Franklin residing in this beautiful world. \r\n                            </p>\r\n\r\n                            <hr/>\r\n\r\n                            <div class=\"text-left\">\r\n                                <p class=\"text-muted\"><strong>Full Name :</strong> <span class=\"ml-2\">Michael A. Franklin</span></p>\r\n\r\n                                <p class=\"text-muted\"><strong>Mobile :</strong><span class=\"ml-2\">(+12) 123 1234 567</span></p>\r\n\r\n                                <p class=\"text-muted\"><strong>Email :</strong> <span class=\"ml-2\">coderthemes@gmail.com</span></p>\r\n\r\n                                <p class=\"text-muted\"><strong>Location :</strong> <span class=\"ml-2\">USA</span> <a href=\"#\">&nbsp;View Loaction on Map</a></p>\r\n\r\n                                <p class=\"text-muted\"><strong>Languages :</strong>\r\n                                    <span class=\"ml-2\"> English, German, Spanish </span>\r\n                                </p>\r\n                               \r\n\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                    <!-- Personal-Information -->\r\n\r\n                    \r\n                    <!-- Messages-->\r\n                    <div class=\"card\">\r\n                        <div class=\"card-body\">\r\n                            <h4 class=\"header-title mb-3\">Location on the Map</h4>\r\n\r\n                            <div class=\"inbox-widget\">\r\n                              \r\n                            </div> <!-- end inbox-widget -->\r\n                        </div> <!-- end card-body-->\r\n                    </div> <!-- end card-->\r\n\r\n                </div> <!-- end col-->\r\n\r\n                <div class=\"col-lg-8\">\r\n\r\n                    <!-- Chart-->\r\n                    <div class=\"card\">\r\n                        <div class=\"card-body\">\r\n                            <h4 class=\"header-title mb-3\">Calender</h4>\r\n                            <div style=\"height: 260px;\" >\r\n                            </div>        \r\n                        </div>\r\n                    </div>\r\n                    <!-- End Chart-->\r\n\r\n                    <div class=\"row\">\r\n                        <div class=\"col-sm-4\">\r\n                            <div class=\"card tilebox-one\">\r\n                                <div class=\"card-body\">\r\n                                    <h6 class=\"text-muted text-uppercase mt-0\">Upocoming Appointments</h6>\r\n                                    <h3 class=\"m-b-20\">1,587</h3>\r\n                                    <span class=\"badge badge-primary\"> +11% </span> <span class=\"text-muted\">From previous period</span>\r\n                                </div> <!-- end card-body-->\r\n                            </div> <!--end card-->\r\n                        </div><!-- end col -->\r\n\r\n                        <div class=\"col-sm-4\">\r\n                            <div class=\"card tilebox-one\">\r\n                                <div class=\"card-body\">\r\n                                    <h6 class=\"text-muted text-uppercase mt-0\">Total Appointments</h6>\r\n                                    <h3 class=\"m-b-20\">$<span>46,782</span></h3>\r\n                                    <span class=\"badge badge-danger\"> -29% </span> <span class=\"text-muted\">From previous period</span>\r\n                                </div> <!-- end card-body-->\r\n                            </div> <!--end card-->\r\n                        </div><!-- end col -->\r\n\r\n                        <div class=\"col-sm-4\">\r\n                            <div class=\"card tilebox-one\">\r\n                                <div class=\"card-body\">\r\n                                    <h6 class=\"text-muted text-uppercase mt-0\">Total Hours</h6>\r\n                                    <h3 class=\"m-b-20\">1,890</h3>\r\n                                    <span class=\"badge badge-primary\"> +89% </span> <span class=\"text-muted\">Last year</span>\r\n                                </div> <!-- end card-body-->\r\n                            </div> <!--end card-->\r\n                        </div><!-- end col -->\r\n\r\n                    </div>\r\n                    <!-- end row -->\r\n\r\n\r\n                    <div class=\"card\">\r\n                        <div class=\"card-body\">\r\n                            <h4 class=\"header-title mb-3\">Appoinments</h4>\r\n\r\n                            <div class=\"table-responsive\">\r\n                                <table class=\"table table-hover table-centered mb-0\">\r\n                                    <thead>\r\n                                        <tr>\r\n                                            <th>Product</th>\r\n                                            <th>Price</th>\r\n                                            <th>Stock</th>\r\n                                            <th>Amount</th>\r\n                                        </tr>\r\n                                    </thead>\r\n                                    <tbody>\r\n                                        <tr>\r\n                                            <td>ASOS Ridley High Waist</td>\r\n                                            <td>$79.49</td>\r\n                                            <td><span class=\"badge badge-primary\">82 Pcs</span></td>\r\n                                            <td>$6,518.18</td>\r\n                                        </tr>\r\n                                        <tr>\r\n                                            <td>Marco Lightweight Shirt</td>\r\n                                            <td>$128.50</td>\r\n                                            <td><span class=\"badge badge-primary\">37 Pcs</span></td>\r\n                                            <td>$4,754.50</td>\r\n                                        </tr>\r\n                                        <tr>\r\n                                            <td>Half Sleeve Shirt</td>\r\n                                            <td>$39.99</td>\r\n                                            <td><span class=\"badge badge-primary\">64 Pcs</span></td>\r\n                                            <td>$2,559.36</td>\r\n                                        </tr>\r\n                                        <tr>\r\n                                            <td>Lightweight Jacket</td>\r\n                                            <td>$20.00</td>\r\n                                            <td><span class=\"badge badge-primary\">184 Pcs</span></td>\r\n                                            <td>$3,680.00</td>\r\n                                        </tr>\r\n                                        <tr>\r\n                                            <td>Marco Shoes</td>\r\n                                            <td>$28.49</td>\r\n                                            <td><span class=\"badge badge-primary\">69 Pcs</span></td>\r\n                                            <td>$1,965.81</td>\r\n                                        </tr>\r\n                                    </tbody>\r\n                                </table>\r\n                            </div> <!-- end table responsive-->\r\n                        </div> <!-- end col-->\r\n                    </div> <!-- end row-->\r\n\r\n                </div>\r\n                <!-- end col -->\r\n\r\n            </div>\r\n            <!-- end row -->\r\n            \r\n        </div> <!-- container -->\r\n\r\n    </div> <!-- content -->\r\n\r\n    <!-- Footer Start -->\r\n   \r\n    <!-- end Footer -->\r\n\r\n</div>\r\n\r\n"

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./customer/customer.module": [
		"./src/app/customer/customer.module.ts",
		"customer-customer-module"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return __webpack_require__.e(ids[1]).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var _forgot_password_forgot_password_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./forgot-password/forgot-password.component */ "./src/app/forgot-password/forgot-password.component.ts");
/* harmony import */ var _customer_customer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./customer/customer.component */ "./src/app/customer/customer.component.ts");
/* harmony import */ var _guards_auth_guard__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./guards/auth.guard */ "./src/app/guards/auth.guard.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var routes = [
    { path: '', pathMatch: 'full', component: _login_login_component__WEBPACK_IMPORTED_MODULE_2__["LoginComponent"] },
    { path: 'login', pathMatch: 'full', component: _login_login_component__WEBPACK_IMPORTED_MODULE_2__["LoginComponent"] },
    { path: 'forgot-password', pathMatch: 'full', component: _forgot_password_forgot_password_component__WEBPACK_IMPORTED_MODULE_3__["ForgotPasswordComponent"] },
    {
        path: '',
        component: _customer_customer_component__WEBPACK_IMPORTED_MODULE_4__["CustomerComponent"],
        children: [
            { path: 'customer', loadChildren: './customer/customer.module#CustomerModule', canActivate: [_guards_auth_guard__WEBPACK_IMPORTED_MODULE_5__["AuthGuard"]], }
        ],
    },
];
//console.log(routes);
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule(router) {
        //console.log('test1');
        this.router = router;
    }
    AppRoutingModule.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }
    ]; };
    AppRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes, { useHash: true, preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_1__["PreloadAllModules"] })],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]])
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.less":
/*!************************************!*\
  !*** ./src/app/app.component.less ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQubGVzcyJ9 */"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.title = 'app';
    }
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/index.js!./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.less */ "./src/app/app.component.less")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var ngx_bootstrap_modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-bootstrap/modal */ "./node_modules/ngx-bootstrap/modal/fesm5/ngx-bootstrap-modal.js");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/fesm5/ngx-spinner.js");
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ngx-toastr */ "./node_modules/ngx-toastr/fesm5/ngx-toastr.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _core_material_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./core/material-module */ "./src/app/core/material-module.ts");
/* harmony import */ var _core_shared_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./core/shared.module */ "./src/app/core/shared.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var _customer_customer_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./customer/customer.component */ "./src/app/customer/customer.component.ts");
/* harmony import */ var _customer_layouts_header_header_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./customer/layouts/header/header.component */ "./src/app/customer/layouts/header/header.component.ts");
/* harmony import */ var _customer_layouts_footer_footer_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./customer/layouts/footer/footer.component */ "./src/app/customer/layouts/footer/footer.component.ts");
/* harmony import */ var _customer_layouts_sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./customer/layouts/sidebar/sidebar.component */ "./src/app/customer/layouts/sidebar/sidebar.component.ts");
/* harmony import */ var _forgot_password_forgot_password_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./forgot-password/forgot-password.component */ "./src/app/forgot-password/forgot-password.component.ts");
/* harmony import */ var ngx_bootstrap_datepicker__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ngx-bootstrap/datepicker */ "./node_modules/ngx-bootstrap/datepicker/fesm5/ngx-bootstrap-datepicker.js");
/* harmony import */ var angular_calendar__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! angular-calendar */ "./node_modules/angular-calendar/fesm5/angular-calendar.js");
/* harmony import */ var angular_calendar_date_adapters_date_fns__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! angular-calendar/date-adapters/date-fns */ "./node_modules/angular-calendar/date-adapters/esm/date-fns/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



















var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_9__["AppComponent"],
                _login_login_component__WEBPACK_IMPORTED_MODULE_10__["LoginComponent"],
                _customer_customer_component__WEBPACK_IMPORTED_MODULE_11__["CustomerComponent"],
                _customer_layouts_header_header_component__WEBPACK_IMPORTED_MODULE_12__["HeaderComponent"],
                _customer_layouts_footer_footer_component__WEBPACK_IMPORTED_MODULE_13__["FooterComponent"],
                _customer_layouts_sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_14__["SidebarComponent"],
                _forgot_password_forgot_password_component__WEBPACK_IMPORTED_MODULE_15__["ForgotPasswordComponent"],
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_6__["AppRoutingModule"],
                _core_material_module__WEBPACK_IMPORTED_MODULE_7__["MaterialModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_2__["BrowserAnimationsModule"],
                ngx_bootstrap_datepicker__WEBPACK_IMPORTED_MODULE_16__["BsDatepickerModule"].forRoot(),
                ngx_spinner__WEBPACK_IMPORTED_MODULE_4__["NgxSpinnerModule"],
                ngx_bootstrap_modal__WEBPACK_IMPORTED_MODULE_3__["ModalModule"].forRoot(),
                ngx_toastr__WEBPACK_IMPORTED_MODULE_5__["ToastrModule"].forRoot({ maxOpened: 1 }),
                _core_shared_module__WEBPACK_IMPORTED_MODULE_8__["SharedModule"],
                angular_calendar__WEBPACK_IMPORTED_MODULE_17__["CalendarModule"].forRoot({ provide: angular_calendar__WEBPACK_IMPORTED_MODULE_17__["DateAdapter"], useFactory: angular_calendar_date_adapters_date_fns__WEBPACK_IMPORTED_MODULE_18__["adapterFactory"] }),
            ],
            providers: [],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_9__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/core/material-module.ts":
/*!*****************************************!*\
  !*** ./src/app/core/material-module.ts ***!
  \*****************************************/
/*! exports provided: MaterialModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MaterialModule", function() { return MaterialModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/cdk/a11y */ "./node_modules/@angular/cdk/esm5/a11y.es5.js");
/* harmony import */ var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/cdk/drag-drop */ "./node_modules/@angular/cdk/esm5/drag-drop.es5.js");
/* harmony import */ var _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/cdk/portal */ "./node_modules/@angular/cdk/esm5/portal.es5.js");
/* harmony import */ var _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/cdk/scrolling */ "./node_modules/@angular/cdk/esm5/scrolling.es5.js");
/* harmony import */ var _angular_cdk_stepper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/cdk/stepper */ "./node_modules/@angular/cdk/esm5/stepper.es5.js");
/* harmony import */ var _angular_cdk_table__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/cdk/table */ "./node_modules/@angular/cdk/esm5/table.es5.js");
/* harmony import */ var _angular_cdk_tree__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/cdk/tree */ "./node_modules/@angular/cdk/esm5/tree.es5.js");
/* harmony import */ var _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/autocomplete */ "./node_modules/@angular/material/esm5/autocomplete.es5.js");
/* harmony import */ var _angular_material_badge__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/badge */ "./node_modules/@angular/material/esm5/badge.es5.js");
/* harmony import */ var _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/bottom-sheet */ "./node_modules/@angular/material/esm5/bottom-sheet.es5.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/esm5/button.es5.js");
/* harmony import */ var _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material/button-toggle */ "./node_modules/@angular/material/esm5/button-toggle.es5.js");
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/material/card */ "./node_modules/@angular/material/esm5/card.es5.js");
/* harmony import */ var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/material/checkbox */ "./node_modules/@angular/material/esm5/checkbox.es5.js");
/* harmony import */ var _angular_material_chips__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/material/chips */ "./node_modules/@angular/material/esm5/chips.es5.js");
/* harmony import */ var _angular_material_stepper__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/material/stepper */ "./node_modules/@angular/material/esm5/stepper.es5.js");
/* harmony import */ var _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/material/datepicker */ "./node_modules/@angular/material/esm5/datepicker.es5.js");
/* harmony import */ var _angular_material_divider__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/material/divider */ "./node_modules/@angular/material/esm5/divider.es5.js");
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/material/expansion */ "./node_modules/@angular/material/esm5/expansion.es5.js");
/* harmony import */ var _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/material/grid-list */ "./node_modules/@angular/material/esm5/grid-list.es5.js");
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/material/icon */ "./node_modules/@angular/material/esm5/icon.es5.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/esm5/input.es5.js");
/* harmony import */ var _angular_material_list__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/material/list */ "./node_modules/@angular/material/esm5/list.es5.js");
/* harmony import */ var _angular_material_menu__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/material/menu */ "./node_modules/@angular/material/esm5/menu.es5.js");
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/material/core */ "./node_modules/@angular/material/esm5/core.es5.js");
/* harmony import */ var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/material/paginator */ "./node_modules/@angular/material/esm5/paginator.es5.js");
/* harmony import */ var _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @angular/material/progress-bar */ "./node_modules/@angular/material/esm5/progress-bar.es5.js");
/* harmony import */ var _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @angular/material/progress-spinner */ "./node_modules/@angular/material/esm5/progress-spinner.es5.js");
/* harmony import */ var _angular_material_radio__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @angular/material/radio */ "./node_modules/@angular/material/esm5/radio.es5.js");
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @angular/material/select */ "./node_modules/@angular/material/esm5/select.es5.js");
/* harmony import */ var _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @angular/material/sidenav */ "./node_modules/@angular/material/esm5/sidenav.es5.js");
/* harmony import */ var _angular_material_slider__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @angular/material/slider */ "./node_modules/@angular/material/esm5/slider.es5.js");
/* harmony import */ var _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @angular/material/slide-toggle */ "./node_modules/@angular/material/esm5/slide-toggle.es5.js");
/* harmony import */ var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! @angular/material/snack-bar */ "./node_modules/@angular/material/esm5/snack-bar.es5.js");
/* harmony import */ var _angular_material_sort__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! @angular/material/sort */ "./node_modules/@angular/material/esm5/sort.es5.js");
/* harmony import */ var _angular_material_table__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! @angular/material/table */ "./node_modules/@angular/material/esm5/table.es5.js");
/* harmony import */ var _angular_material_tabs__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! @angular/material/tabs */ "./node_modules/@angular/material/esm5/tabs.es5.js");
/* harmony import */ var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! @angular/material/toolbar */ "./node_modules/@angular/material/esm5/toolbar.es5.js");
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! @angular/material/tooltip */ "./node_modules/@angular/material/esm5/tooltip.es5.js");
/* harmony import */ var _angular_material_tree__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! @angular/material/tree */ "./node_modules/@angular/material/esm5/tree.es5.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};









































var MaterialModule = /** @class */ (function () {
    function MaterialModule() {
    }
    MaterialModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            exports: [
                _angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_1__["A11yModule"],
                _angular_cdk_stepper__WEBPACK_IMPORTED_MODULE_5__["CdkStepperModule"],
                _angular_cdk_table__WEBPACK_IMPORTED_MODULE_6__["CdkTableModule"],
                _angular_cdk_tree__WEBPACK_IMPORTED_MODULE_7__["CdkTreeModule"],
                _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_2__["DragDropModule"],
                _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_8__["MatAutocompleteModule"],
                _angular_material_badge__WEBPACK_IMPORTED_MODULE_9__["MatBadgeModule"],
                _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_10__["MatBottomSheetModule"],
                _angular_material_button__WEBPACK_IMPORTED_MODULE_11__["MatButtonModule"],
                _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_12__["MatButtonToggleModule"],
                _angular_material_card__WEBPACK_IMPORTED_MODULE_13__["MatCardModule"],
                _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_14__["MatCheckboxModule"],
                _angular_material_chips__WEBPACK_IMPORTED_MODULE_15__["MatChipsModule"],
                _angular_material_stepper__WEBPACK_IMPORTED_MODULE_16__["MatStepperModule"],
                _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_17__["MatDatepickerModule"],
                _angular_material_divider__WEBPACK_IMPORTED_MODULE_18__["MatDividerModule"],
                _angular_material_expansion__WEBPACK_IMPORTED_MODULE_19__["MatExpansionModule"],
                _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_20__["MatGridListModule"],
                _angular_material_icon__WEBPACK_IMPORTED_MODULE_21__["MatIconModule"],
                _angular_material_input__WEBPACK_IMPORTED_MODULE_22__["MatInputModule"],
                _angular_material_list__WEBPACK_IMPORTED_MODULE_23__["MatListModule"],
                _angular_material_menu__WEBPACK_IMPORTED_MODULE_24__["MatMenuModule"],
                _angular_material_core__WEBPACK_IMPORTED_MODULE_25__["MatNativeDateModule"],
                _angular_material_paginator__WEBPACK_IMPORTED_MODULE_26__["MatPaginatorModule"],
                _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_27__["MatProgressBarModule"],
                _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_28__["MatProgressSpinnerModule"],
                _angular_material_radio__WEBPACK_IMPORTED_MODULE_29__["MatRadioModule"],
                _angular_material_core__WEBPACK_IMPORTED_MODULE_25__["MatRippleModule"],
                _angular_material_select__WEBPACK_IMPORTED_MODULE_30__["MatSelectModule"],
                _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_31__["MatSidenavModule"],
                _angular_material_slider__WEBPACK_IMPORTED_MODULE_32__["MatSliderModule"],
                _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_33__["MatSlideToggleModule"],
                _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_34__["MatSnackBarModule"],
                _angular_material_sort__WEBPACK_IMPORTED_MODULE_35__["MatSortModule"],
                _angular_material_table__WEBPACK_IMPORTED_MODULE_36__["MatTableModule"],
                _angular_material_tabs__WEBPACK_IMPORTED_MODULE_37__["MatTabsModule"],
                _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_38__["MatToolbarModule"],
                _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_39__["MatTooltipModule"],
                _angular_material_tree__WEBPACK_IMPORTED_MODULE_40__["MatTreeModule"],
                _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_3__["PortalModule"],
                _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_4__["ScrollingModule"],
            ]
        })
    ], MaterialModule);
    return MaterialModule;
}());

/**  Copyright 2020 Google LLC. All Rights Reserved.
    Use of this source code is governed by an MIT-style license that
    can be found in the LICENSE file at http://angular.io/license */ 


/***/ }),

/***/ "./src/app/core/shared.module.ts":
/*!***************************************!*\
  !*** ./src/app/core/shared.module.ts ***!
  \***************************************/
/*! exports provided: SharedModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedModule", function() { return SharedModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _shared_components_child_child_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../shared-components/child/child.component */ "./src/app/shared-components/child/child.component.ts");
/* harmony import */ var _shared_components_calender_calendar_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../shared-components/calender/calendar.component */ "./src/app/shared-components/calender/calendar.component.ts");
/* harmony import */ var _shared_components_profile_profile_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../shared-components/profile/profile.component */ "./src/app/shared-components/profile/profile.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



// import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


// import { MDBBootstrapModule } from 'angular-bootstrap-md';



var SharedModule = /** @class */ (function () {
    function SharedModule() {
    }
    SharedModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ReactiveFormsModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClientModule"],
            ],
            declarations: [
                _shared_components_child_child_component__WEBPACK_IMPORTED_MODULE_4__["ChildComponent"],
                _shared_components_calender_calendar_component__WEBPACK_IMPORTED_MODULE_5__["CalendarComponent"],
                _shared_components_profile_profile_component__WEBPACK_IMPORTED_MODULE_6__["ProfileComponent"]
            ],
            providers: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["DatePipe"]],
            exports: [
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ReactiveFormsModule"],
                _shared_components_child_child_component__WEBPACK_IMPORTED_MODULE_4__["ChildComponent"],
                _shared_components_calender_calendar_component__WEBPACK_IMPORTED_MODULE_5__["CalendarComponent"],
                _shared_components_profile_profile_component__WEBPACK_IMPORTED_MODULE_6__["ProfileComponent"]
            ]
        })
    ], SharedModule);
    return SharedModule;
}());



/***/ }),

/***/ "./src/app/customer/customer.component.less":
/*!**************************************************!*\
  !*** ./src/app/customer/customer.component.less ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".div-scrollable {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  height: 4000px;\n}\nmat-toolbar {\n  position: relative;\n  z-index: 0;\n}\n@media screen and (min-width: 960px) {\n  mat-toolbar {\n    z-index: 50;\n  }\n}\n@media screen and (max-width: 599px) {\n  mat-toolbar {\n    z-index: 0;\n  }\n}\n@media screen and (max-width: 599px) {\n  .main-sidenav-container {\n    width: 100%;\n    height: calc(100vh - 56px);\n    z-index: 100;\n  }\n}\n@media screen and (min-width: 600px) {\n  .main-sidenav-container {\n    width: 100%;\n    height: calc(100vh - 64px);\n  }\n}\n.example-spacer {\n  flex: 1 1 auto;\n}\n.mat-elevation-z6 {\n  background: rgba(0, 0, 0, 0.72);\n  color: #fff;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY3VzdG9tZXIvQzovVXNlcnMvTmV3L0RvY3VtZW50cy9HaXRIdWIvY2FyZS9zcmMvYXBwL2N1c3RvbWVyL2N1c3RvbWVyLmNvbXBvbmVudC5sZXNzIiwic3JjL2FwcC9jdXN0b21lci9jdXN0b21lci5jb21wb25lbnQubGVzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFJRTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtBQ0hKO0FETUU7RUFDRSxrQkFBQTtFQUNBLFVBQUE7QUNKSjtBRE9FO0VBQ0U7SUFDRyxXQUFBO0VDTEw7QUFDRjtBRFFFO0VBQ0U7SUFDRyxVQUFBO0VDTkw7QUFDRjtBRFNFO0VBQ0k7SUFDSSxXQUFBO0lBQ0EsMEJBQUE7SUFDQSxZQUFBO0VDUFI7QUFDRjtBRFVFO0VBQ0U7SUFDSSxXQUFBO0lBQ0EsMEJBQUE7RUNSTjtBQUNGO0FEV0U7RUFDRSxjQUFBO0FDVEo7QURZRTtFQUNFLCtCQUFBO0VBQ0EsV0FBQTtBQ1ZKIiwiZmlsZSI6InNyYy9hcHAvY3VzdG9tZXIvY3VzdG9tZXIuY29tcG9uZW50Lmxlc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcbm1hdC1zaWRlbmF2IHtcbiAgfVxuICAgICAgICBcbiAgLmRpdi1zY3JvbGxhYmxlIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgaGVpZ2h0OiA0MDAwcHg7XG4gIH1cbiAgXG4gIG1hdC10b29sYmFyIHtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgei1pbmRleDogMDtcbiAgfVxuICBcbiAgQG1lZGlhIHNjcmVlbiBhbmQgKG1pbi13aWR0aDogOTYwcHgpIHtcbiAgICBtYXQtdG9vbGJhciB7XG4gICAgICAgei1pbmRleDogNTA7XG4gICAgfVxuICB9XG4gIFxuICBAbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA1OTlweCkge1xuICAgIG1hdC10b29sYmFyIHtcbiAgICAgICB6LWluZGV4OiAwO1xuICAgIH1cbiAgfVxuICBcbiAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNTk5cHgpIHtcbiAgICAgIC5tYWluLXNpZGVuYXYtY29udGFpbmVyIHtcbiAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICBoZWlnaHQ6IGNhbGMoMTAwdmggLSA1NnB4KTtcbiAgICAgICAgICB6LWluZGV4OiAxMDA7XG4gICAgICB9XG4gIH1cbiAgXG4gIEBtZWRpYSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDYwMHB4KSB7XG4gICAgLm1haW4tc2lkZW5hdi1jb250YWluZXIge1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgaGVpZ2h0OiBjYWxjKDEwMHZoIC0gNjRweCk7XG4gICAgfVxuICB9XG5cbiAgLmV4YW1wbGUtc3BhY2VyIHtcbiAgICBmbGV4OiAxIDEgYXV0bztcbiAgfVxuXG4gIC5tYXQtZWxldmF0aW9uLXo2e1xuICAgIGJhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgMC43Mik7XG4gICAgY29sb3I6ICNmZmY7XG4gIH0iLCIuZGl2LXNjcm9sbGFibGUge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgaGVpZ2h0OiA0MDAwcHg7XG59XG5tYXQtdG9vbGJhciB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgei1pbmRleDogMDtcbn1cbkBtZWRpYSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDk2MHB4KSB7XG4gIG1hdC10b29sYmFyIHtcbiAgICB6LWluZGV4OiA1MDtcbiAgfVxufVxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNTk5cHgpIHtcbiAgbWF0LXRvb2xiYXIge1xuICAgIHotaW5kZXg6IDA7XG4gIH1cbn1cbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDU5OXB4KSB7XG4gIC5tYWluLXNpZGVuYXYtY29udGFpbmVyIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IGNhbGMoMTAwdmggLSA1NnB4KTtcbiAgICB6LWluZGV4OiAxMDA7XG4gIH1cbn1cbkBtZWRpYSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDYwMHB4KSB7XG4gIC5tYWluLXNpZGVuYXYtY29udGFpbmVyIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IGNhbGMoMTAwdmggLSA2NHB4KTtcbiAgfVxufVxuLmV4YW1wbGUtc3BhY2VyIHtcbiAgZmxleDogMSAxIGF1dG87XG59XG4ubWF0LWVsZXZhdGlvbi16NiB7XG4gIGJhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgMC43Mik7XG4gIGNvbG9yOiAjZmZmO1xufVxuIl19 */"

/***/ }),

/***/ "./src/app/customer/customer.component.ts":
/*!************************************************!*\
  !*** ./src/app/customer/customer.component.ts ***!
  \************************************************/
/*! exports provided: CustomerComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerComponent", function() { return CustomerComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_cdk_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/cdk/layout */ "./node_modules/@angular/cdk/esm5/layout.es5.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _services_restservices_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/restservices/auth.service */ "./src/app/services/restservices/auth.service.ts");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/fesm5/ngx-spinner.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var CustomerComponent = /** @class */ (function () {
    function CustomerComponent(router, spinner, bpo, authService) {
        this.router = router;
        this.spinner = spinner;
        this.bpo = bpo;
        this.authService = authService;
        this.version = _angular_material__WEBPACK_IMPORTED_MODULE_1__["VERSION"];
        this.mode = 'side';
        this.opened = true;
        this.layoutGap = '64';
        this.fixedInViewport = true;
    }
    CustomerComponent.prototype.ngOnInit = function () {
        var _this = this;
        var breakpoints = Object.keys(_angular_cdk_layout__WEBPACK_IMPORTED_MODULE_2__["Breakpoints"]).map(function (key) { return _angular_cdk_layout__WEBPACK_IMPORTED_MODULE_2__["Breakpoints"][key]; });
        this.bpo.observe(breakpoints)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (bst) { return bst.matches; }))
            .subscribe(function (matched) {
            console.log('matched');
            _this.determineSidenavMode();
            _this.determineLayoutGap();
        });
    };
    CustomerComponent.prototype.determineSidenavMode = function () {
        if (this.isExtraSmallDevice() ||
            this.isSmallDevice()) {
            this.fixedInViewport = false;
            this.mode = 'over';
            this.opened = false;
            return;
        }
        this.fixedInViewport = true;
        this.mode = 'side';
    };
    CustomerComponent.prototype.determineLayoutGap = function () {
        if (this.isExtraSmallDevice() || this.isSmallDevice()) {
            this.layoutGap = '0';
            return;
        }
        this.layoutGap = '64';
    };
    CustomerComponent.prototype.isExtraSmallDevice = function () {
        return this.bpo.isMatched(_angular_cdk_layout__WEBPACK_IMPORTED_MODULE_2__["Breakpoints"].XSmall);
    };
    CustomerComponent.prototype.isSmallDevice = function () {
        return this.bpo.isMatched(_angular_cdk_layout__WEBPACK_IMPORTED_MODULE_2__["Breakpoints"].Small);
    };
    CustomerComponent.prototype.logout = function () {
        var _this = this;
        this.authService.logout();
        this.spinner.show();
        setTimeout(function () {
            _this.spinner.hide();
            _this.router.navigateByUrl('/login');
        }, 3000);
    };
    CustomerComponent.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
        { type: ngx_spinner__WEBPACK_IMPORTED_MODULE_5__["NgxSpinnerService"] },
        { type: _angular_cdk_layout__WEBPACK_IMPORTED_MODULE_2__["BreakpointObserver"] },
        { type: _services_restservices_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"] }
    ]; };
    CustomerComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-customer',
            template: __webpack_require__(/*! raw-loader!./customer.component.html */ "./node_modules/raw-loader/index.js!./src/app/customer/customer.component.html"),
            styles: [__webpack_require__(/*! ./customer.component.less */ "./src/app/customer/customer.component.less")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"], ngx_spinner__WEBPACK_IMPORTED_MODULE_5__["NgxSpinnerService"], _angular_cdk_layout__WEBPACK_IMPORTED_MODULE_2__["BreakpointObserver"], _services_restservices_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"]])
    ], CustomerComponent);
    return CustomerComponent;
}());



/***/ }),

/***/ "./src/app/customer/layouts/footer/footer.component.less":
/*!***************************************************************!*\
  !*** ./src/app/customer/layouts/footer/footer.component.less ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2N1c3RvbWVyL2xheW91dHMvZm9vdGVyL2Zvb3Rlci5jb21wb25lbnQubGVzcyJ9 */"

/***/ }),

/***/ "./src/app/customer/layouts/footer/footer.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/customer/layouts/footer/footer.component.ts ***!
  \*************************************************************/
/*! exports provided: FooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return FooterComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var FooterComponent = /** @class */ (function () {
    function FooterComponent() {
    }
    FooterComponent.prototype.ngOnInit = function () {
    };
    FooterComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-footer',
            template: __webpack_require__(/*! raw-loader!./footer.component.html */ "./node_modules/raw-loader/index.js!./src/app/customer/layouts/footer/footer.component.html"),
            styles: [__webpack_require__(/*! ./footer.component.less */ "./src/app/customer/layouts/footer/footer.component.less")]
        }),
        __metadata("design:paramtypes", [])
    ], FooterComponent);
    return FooterComponent;
}());



/***/ }),

/***/ "./src/app/customer/layouts/header/header.component.less":
/*!***************************************************************!*\
  !*** ./src/app/customer/layouts/header/header.component.less ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2N1c3RvbWVyL2xheW91dHMvaGVhZGVyL2hlYWRlci5jb21wb25lbnQubGVzcyJ9 */"

/***/ }),

/***/ "./src/app/customer/layouts/header/header.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/customer/layouts/header/header.component.ts ***!
  \*************************************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var HeaderComponent = /** @class */ (function () {
    function HeaderComponent() {
    }
    HeaderComponent.prototype.ngOnInit = function () {
    };
    HeaderComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-header',
            template: __webpack_require__(/*! raw-loader!./header.component.html */ "./node_modules/raw-loader/index.js!./src/app/customer/layouts/header/header.component.html"),
            styles: [__webpack_require__(/*! ./header.component.less */ "./src/app/customer/layouts/header/header.component.less")]
        }),
        __metadata("design:paramtypes", [])
    ], HeaderComponent);
    return HeaderComponent;
}());



/***/ }),

/***/ "./src/app/customer/layouts/sidebar/sidebar.component.less":
/*!*****************************************************************!*\
  !*** ./src/app/customer/layouts/sidebar/sidebar.component.less ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".mat-toolbar.mat-primary {\n  background-color: red;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY3VzdG9tZXIvbGF5b3V0cy9zaWRlYmFyL0M6L1VzZXJzL05ldy9Eb2N1bWVudHMvR2l0SHViL2NhcmUvc3JjL2FwcC9jdXN0b21lci9sYXlvdXRzL3NpZGViYXIvc2lkZWJhci5jb21wb25lbnQubGVzcyIsInNyYy9hcHAvY3VzdG9tZXIvbGF5b3V0cy9zaWRlYmFyL3NpZGViYXIuY29tcG9uZW50Lmxlc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUM7RUFDRyxxQkFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvY3VzdG9tZXIvbGF5b3V0cy9zaWRlYmFyL3NpZGViYXIuY29tcG9uZW50Lmxlc3MiLCJzb3VyY2VzQ29udGVudCI6WyIgLm1hdC10b29sYmFyLm1hdC1wcmltYXJ5e1xuICAgIGJhY2tncm91bmQtY29sb3I6IHJlZDtcbiAgfVxuIiwiLm1hdC10b29sYmFyLm1hdC1wcmltYXJ5IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmVkO1xufVxuIl19 */"

/***/ }),

/***/ "./src/app/customer/layouts/sidebar/sidebar.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/customer/layouts/sidebar/sidebar.component.ts ***!
  \***************************************************************/
/*! exports provided: ROUTES, SidebarComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ROUTES", function() { return ROUTES; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SidebarComponent", function() { return SidebarComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ROUTES = [
    { path: '/customer/dashboard', title: 'Dashboard', icon: 'dashboard', class: '' },
    { path: '/customer/usermanagement', title: 'Carer Management', icon: 'person', class: '' },
    { path: '/customer/clientmanagement', title: 'Client Management', icon: 'person', class: '' },
    { path: '/customer/appointment', title: 'Appointment Management', icon: 'person', class: '' }
];
var SidebarComponent = /** @class */ (function () {
    function SidebarComponent() {
        this.role = JSON.parse(sessionStorage.getItem('role'));
    }
    SidebarComponent.prototype.ngOnInit = function () {
        if (this.role == 'carer') {
            this.menuItems = [
                { path: '/customer/appointment', title: 'Appointment', icon: 'person', class: '' },
            ];
        }
        else {
            this.menuItems = [
                { path: '/customer/dashboard', title: 'Dashboard', icon: 'dashboard', class: '' },
                { path: '/customer/usermanagement', title: 'Carer', icon: 'person', class: '' },
                { path: '/customer/clientmanagement', title: 'Client', icon: 'person', class: '' },
                { path: '/customer/appointment', title: 'Appointment', icon: 'person', class: '' },
                { path: '/customer/dairy', title: 'Dairy', icon: 'person', class: '' },
                { path: '/customer/groups', title: 'Groups', icon: 'person', class: '' }
            ];
        }
    };
    SidebarComponent.prototype.isMobileMenu = function () {
        if ($(window).width() > 991) {
            return false;
        }
        return true;
    };
    ;
    SidebarComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-sidebar',
            template: __webpack_require__(/*! raw-loader!./sidebar.component.html */ "./node_modules/raw-loader/index.js!./src/app/customer/layouts/sidebar/sidebar.component.html"),
            styles: [__webpack_require__(/*! ./sidebar.component.less */ "./src/app/customer/layouts/sidebar/sidebar.component.less")]
        }),
        __metadata("design:paramtypes", [])
    ], SidebarComponent);
    return SidebarComponent;
}());



/***/ }),

/***/ "./src/app/forgot-password/forgot-password.component.less":
/*!****************************************************************!*\
  !*** ./src/app/forgot-password/forgot-password.component.less ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "*:focus {\n  outline: none;\n}\n.error-span {\n  font-family: \"Nunito\", sans-serif;\n  font-size: 12px;\n  color: #fa5c7c;\n}\n.popup-error {\n  margin-left: 25%;\n}\n.pageheading {\n  color: #333333;\n  font-family: \"Nunito\", sans-serif;\n  font-size: 20px;\n  margin-bottom: 10px;\n  margin-left: 2px;\n}\n.page-container {\n  margin-top: 5px;\n  margin-left: 5px;\n}\n.page-content {\n  margin-top: 5px;\n  margin-left: 5px;\n}\n.form-control {\n  display: block;\n  width: 100%;\n  height: calc(2.25rem + 2px);\n  padding: 0.45rem 0.9rem;\n  font-size: 0.9rem;\n  font-weight: 400;\n  line-height: 1.5;\n  color: #6c757d;\n  background-color: #fff;\n  background-clip: padding-box;\n  border: 1px solid #dee2e6;\n  border-radius: 0.25rem;\n  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;\n}\n.form-control:focus {\n  color: #495057;\n  background-color: #fff;\n  border-color: #c1c9d0;\n  outline: 0;\n}\n.form-control-right {\n  display: block;\n  width: 74%;\n  float: left;\n  height: calc(2.25rem + 2px);\n  padding: 0.45rem 0.9rem;\n  font-size: 0.9rem;\n  font-weight: 400;\n  line-height: 1.5;\n  color: #6c757d;\n  background-color: #fff;\n  background-clip: padding-box;\n  border: 1px solid #dee2e6;\n  border-radius: 0.25rem;\n  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;\n}\n.form-control-right:focus {\n  color: #495057;\n  background-color: #fff;\n  border-color: #c1c9d0;\n  outline: 0;\n}\n.form-label-right {\n  width: 25%;\n  float: left;\n  margin-top: 5px;\n  font-size: 14px;\n}\n.form-group-right {\n  min-height: 45px;\n  max-height: 100px;\n  padding: 1px;\n}\n.btn-success {\n  color: #fff;\n  background-color: #0acf97;\n  border-color: #0acf97;\n}\n.btn-success:hover {\n  box-shadow: 0 2px 6px 0 rgba(10, 207, 151, 0.5);\n}\n.card {\n  position: relative;\n  display: flex;\n  flex-direction: column;\n  min-width: 0;\n  word-wrap: break-word;\n  background-color: #fff;\n  background-clip: initial;\n  border: 1px solid #eef2f7;\n  border-radius: 0.25rem;\n  margin-top: 30%;\n}\n.card-header {\n  padding: 0.75rem 1.5rem;\n  margin-bottom: 0;\n  border-bottom: 1px solid #eef2f7;\n  background-color: #727cf5 !important;\n  color: white;\n  height: 60px;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZm9yZ290LXBhc3N3b3JkL0M6L1VzZXJzL05ldy9Eb2N1bWVudHMvR2l0SHViL2NhcmUvc3JjL2NvbW1vbi5sZXNzIiwic3JjL2FwcC9mb3Jnb3QtcGFzc3dvcmQvZm9yZ290LXBhc3N3b3JkLmNvbXBvbmVudC5sZXNzIiwic3JjL2FwcC9mb3Jnb3QtcGFzc3dvcmQvQzovVXNlcnMvTmV3L0RvY3VtZW50cy9HaXRIdWIvY2FyZS9zcmMvYXBwL2ZvcmdvdC1wYXNzd29yZC9mb3Jnb3QtcGFzc3dvcmQuY29tcG9uZW50Lmxlc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBb0NBO0VBQ0ksYUFBQTtBQ25DSjtBRHNDQTtFQUNFLGlDQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUNwQ0Y7QURzQ0E7RUFDRSxnQkFBQTtBQ3BDRjtBRDBFQTtFQUNFLGNBQUE7RUFDQSxpQ0FBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FDeEVGO0FENEVBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0FDMUVGO0FENEVBO0VBQ0MsZUFBQTtFQUNDLGdCQUFBO0FDMUVGO0FENkVBO0VBQ0ksY0FBQTtFQUNBLFdBQUE7RUFDQSwyQkFBQTtFQUNBLHVCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLHNCQUFBO0VBQ0EsNEJBQUE7RUFDQSx5QkFBQTtFQUNBLHNCQUFBO0VBQ0Esd0VBQUE7QUMzRUo7QUQ0RUk7RUFDQyxjQUFBO0VBQ0Qsc0JBQUE7RUFDQSxxQkFBQTtFQUNBLFVBQUE7QUMxRUo7QUQ4RUE7RUFDSSxjQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7RUFDQSwyQkFBQTtFQUNBLHVCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLHNCQUFBO0VBQ0EsNEJBQUE7RUFDQSx5QkFBQTtFQUNBLHNCQUFBO0VBQ0Esd0VBQUE7QUM1RUo7QUQ2RUk7RUFDQyxjQUFBO0VBQ0Qsc0JBQUE7RUFDQSxxQkFBQTtFQUNBLFVBQUE7QUMzRUo7QUQrRUE7RUFDRSxVQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0FDN0VGO0FEK0VBO0VBQ0ksZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7QUM3RUo7QURtRkE7RUFDSSxXQUFBO0VBQ0EseUJBQUE7RUFDQSxxQkFBQTtBQ2pGSjtBRGtGSTtFQUFRLCtDQUFBO0FDL0VaO0FDdEZBO0VBQ0ksa0JBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0VBQ0EscUJBQUE7RUFDQSxzQkFBQTtFQUNBLHdCQUFBO0VBQ0EseUJBQUE7RUFDQSxzQkFBQTtFQUNBLGVBQUE7QUR3Rko7QUN0RkE7RUFDSSx1QkFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0NBQUE7RUFDQSxvQ0FBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0FEd0ZKIiwiZmlsZSI6InNyYy9hcHAvZm9yZ290LXBhc3N3b3JkL2ZvcmdvdC1wYXNzd29yZC5jb21wb25lbnQubGVzcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIENvbG9yIFZhcmlhYmxlc1xuQHdoaXRlLWNvbG9yOiAgICAgICAgI0ZGRkZGRjtcbkBibGFjay1jb2xvcjogICAgICAgICMwMDAwMDA7XG5AcmVkLWNvbG9yOlx0XHRcdCAgICAgI0Q1MkIxRTtcbkBncmV5MS1jb2xvcjogICAgICAgICNGNkY2RjY7Ly9saWdodCBncmV5XG5AZ3JleTItY29sb3I6ICAgICAgICAjRDhEQURBO1xuQGdyZXkzLWNvbG9yOiAgICAgICAgIzc0NzY3NjtcbkBncmV5NC1jb2xvcjogICAgICAgICMzMzMzMzM7Ly8gZGFyayBncmV5XG5Ab3JhbmdlMS1jb2xvcjogICAgICAjRjlEMEFCOyAvLyBsaWdodCBvcmFuZ2VcbkBvcmFuZ2UyLWNvbG9yOiAgICAgICNGM0ExNTc7XG5Ab3JhbmdlMy1jb2xvcjogICAgICAjRUQ3MDAwOyAvLyBkYXJrIG9yYW5nZVxuQHllbGxvdzEtY29sb3I6ICAgICAgI0ZGRTlCRjsgLy8gbGlnaHQgeWVsbG93XG5AeWVsbG93Mi1jb2xvcjogICAgICAjRkZEMzdGOyBcbkB5ZWxsb3czLWNvbG9yOiAgICAgICNGRkJDM0Q7IC8vIGRhcmsgeWVsbG93XG5AZ3JlZW4xLWNvbG9yOiAgICAgICAjQUJFNEJGOyAvLyBsaWdodCBncmVlblxuQGdyZWVuMi1jb2xvcjogICAgICAgIzU3Qzg4MDsgXG5AZ3JlZW4zLWNvbG9yOiAgICAgICAjMDBBQzNFOyAvLyBkYXJrIGdyZWVuXG5AYmx1ZS1jb2xvcjogICAgICAgICAjQUJEOEVGOyAvLyBsaWdodCBibHVlXG5AYmx1ZTItY29sb3I6ICAgICAgICAjNTdCMURGOyBcbkBibHVlMy1jb2xvcjogICAgICAgICMwMDg4Q0U7IC8vIGRhcmsgYmx1ZVxuLy9oZWFkZXIgY29sb3JcbkBiYWNrZ3JvdW5kLWNvbG9yOiBAd2hpdGUtY29sb3I7XG5AaGVhZGVyLWZvbnQtY29sb3I6IEBibGFjay1jb2xvcjtcblxuXG5cbkBmb250LWZhbWlseSA6ICBcIk51bml0b1wiLHNhbnMtc2VyaWY7XG5cbi8vYm9yZGVyc1xuQGJvcmRlcnMtc3R5bGU6IDFweCBzb2xpZCBAZ3JleTItY29sb3I7IFxuQGJvcmRlci1ib3R0b206IEBib3JkZXJzLXN0eWxlO1xuQGJvcmRlci1ib3R0b20taG92ZXI6IDFweCBzb2xpZCBAcmVkLWNvbG9yO1xuQGhlYWRlci1tZW51LXNlbGVjdGVkOiAycHggc29saWQgQHJlZC1jb2xvcjtcblxuXG4vLyBpbnB1dGJveFxuKjpmb2N1cyB7XG4gICAgb3V0bGluZTogbm9uZTtcbn1cblxuLmVycm9yLXNwYW57XG4gIGZvbnQtZmFtaWx5OiBAZm9udC1mYW1pbHk7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgY29sb3I6ICNmYTVjN2M7XG59XG4ucG9wdXAtZXJyb3J7XG4gIG1hcmdpbi1sZWZ0OiAyNSU7XG59XG5cbi5jb250YWluZXItYm9yZGVyKCkge1xuXHRib3JkZXI6IEBib3JkZXJzLXN0eWxlO1xuXHRib3JkZXItcmFkaXVzOjVweDtcbn1cblxuLmJ1dHRvbigpe1xuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICBmb250LXdlaWdodDogNDAwO1xuICAgIGNvbG9yOiAjNmM3NTdkO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICAgIC13ZWJraXQtdXNlci1zZWxlY3Q6IG5vbmU7XG4gICAgLW1vei11c2VyLXNlbGVjdDogbm9uZTtcbiAgICAtbXMtdXNlci1zZWxlY3Q6IG5vbmU7XG4gICAgdXNlci1zZWxlY3Q6IG5vbmU7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogaW5pdGlhbDtcbiAgICBib3JkZXI6IDFweCBzb2xpZCB0cmFuc3BhcmVudDtcbiAgICBwYWRkaW5nOiAuNDVyZW0gLjlyZW07XG4gICAgZm9udC1zaXplOiAuOXJlbTtcbiAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIGJvcmRlci1yYWRpdXM6IC4xNXJlbTtcbiAgICB0cmFuc2l0aW9uOiBjb2xvciAuMTVzIGVhc2UtaW4tb3V0LGJhY2tncm91bmQtY29sb3IgLjE1cyBlYXNlLWluLW91dCxib3JkZXItY29sb3IgLjE1cyBlYXNlLWluLW91dCxib3gtc2hhZG93IC4xNXMgZWFzZS1pbi1vdXQ7XG59XG5cbi8vIEJ1dHRvbiBjbGFzc2VzXG4uYnV0dG9uLXByaW1hcnkoKXtcbiAgLmJ1dHRvbigpO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMGFjZjk3O1xuICBjb2xvcjogQHdoaXRlLWNvbG9yO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gICY6aG92ZXIge1xuICAgIGJveC1zaGFkb3cgOiAwIDJweCA2cHggMCByZ2JhKDEwLDIwNywxNTEsLjUpO31cbn1cblxuXG4ucGFnZWhlYWRpbmd7XG4gIGNvbG9yOiBAZ3JleTQtY29sb3I7XG4gIGZvbnQtZmFtaWx5OiBAZm9udC1mYW1pbHk7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgbWFyZ2luLWxlZnQ6IDJweDtcblxufVxuXG4ucGFnZS1jb250YWluZXJ7XG4gIG1hcmdpbi10b3A6NXB4O1xuICBtYXJnaW4tbGVmdDo1cHg7IFxufVxuLnBhZ2UtY29udGVudHtcbiBtYXJnaW4tdG9wOjVweDtcbiAgbWFyZ2luLWxlZnQ6NXB4OyAgXG59XG5cbi5mb3JtLWNvbnRyb2wge1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogY2FsYygyLjI1cmVtICsgMnB4KTtcbiAgICBwYWRkaW5nOiAuNDVyZW0gLjlyZW07XG4gICAgZm9udC1zaXplOiAuOXJlbTtcbiAgICBmb250LXdlaWdodDogNDAwO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU7XG4gICAgY29sb3I6ICM2Yzc1N2Q7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgICBiYWNrZ3JvdW5kLWNsaXA6IHBhZGRpbmctYm94O1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICNkZWUyZTY7XG4gICAgYm9yZGVyLXJhZGl1czogLjI1cmVtO1xuICAgIHRyYW5zaXRpb246IGJvcmRlci1jb2xvciAuMTVzIGVhc2UtaW4tb3V0LGJveC1zaGFkb3cgLjE1cyBlYXNlLWluLW91dDtcbiAgICAmOmZvY3VzXG4gICAge2NvbG9yOiAjNDk1MDU3O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gICAgYm9yZGVyLWNvbG9yOiAjYzFjOWQwO1xuICAgIG91dGxpbmU6IDA7XG4gIH07XG59XG5cbi5mb3JtLWNvbnRyb2wtcmlnaHQge1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIHdpZHRoOiA3NCU7XG4gICAgZmxvYXQ6IGxlZnQ7XG4gICAgaGVpZ2h0OiBjYWxjKDIuMjVyZW0gKyAycHgpO1xuICAgIHBhZGRpbmc6IC40NXJlbSAuOXJlbTtcbiAgICBmb250LXNpemU6IC45cmVtO1xuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICBjb2xvcjogIzZjNzU3ZDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICAgIGJhY2tncm91bmQtY2xpcDogcGFkZGluZy1ib3g7XG4gICAgYm9yZGVyOiAxcHggc29saWQgI2RlZTJlNjtcbiAgICBib3JkZXItcmFkaXVzOiAuMjVyZW07XG4gICAgdHJhbnNpdGlvbjogYm9yZGVyLWNvbG9yIC4xNXMgZWFzZS1pbi1vdXQsYm94LXNoYWRvdyAuMTVzIGVhc2UtaW4tb3V0O1xuICAgICY6Zm9jdXNcbiAgICB7Y29sb3I6ICM0OTUwNTc7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgICBib3JkZXItY29sb3I6ICNjMWM5ZDA7XG4gICAgb3V0bGluZTogMDtcbiAgfTtcbn1cblxuLmZvcm0tbGFiZWwtcmlnaHR7XG4gIHdpZHRoOiAyNSU7XG4gIGZsb2F0OiBsZWZ0O1xuICBtYXJnaW4tdG9wOiA1cHg7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cbi5mb3JtLWdyb3VwLXJpZ2h0e1xuICAgIG1pbi1oZWlnaHQ6IDQ1cHg7XG4gICAgbWF4LWhlaWdodDogMTAwcHg7XG4gICAgcGFkZGluZzogMXB4O1xufVxuXG5cblxuXG4uYnRuLXN1Y2Nlc3Mge1xuICAgIGNvbG9yOiAjZmZmO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICMwYWNmOTc7XG4gICAgYm9yZGVyLWNvbG9yOiAjMGFjZjk3O1xuICAgICY6aG92ZXJ7Ym94LXNoYWRvdzogMCAycHggNnB4IDAgcmdiYSgxMCwyMDcsMTUxLC41KTtcbn1cbn0iLCIqOmZvY3VzIHtcbiAgb3V0bGluZTogbm9uZTtcbn1cbi5lcnJvci1zcGFuIHtcbiAgZm9udC1mYW1pbHk6IFwiTnVuaXRvXCIsIHNhbnMtc2VyaWY7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgY29sb3I6ICNmYTVjN2M7XG59XG4ucG9wdXAtZXJyb3Ige1xuICBtYXJnaW4tbGVmdDogMjUlO1xufVxuLnBhZ2VoZWFkaW5nIHtcbiAgY29sb3I6ICMzMzMzMzM7XG4gIGZvbnQtZmFtaWx5OiBcIk51bml0b1wiLCBzYW5zLXNlcmlmO1xuICBmb250LXNpemU6IDIwcHg7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIG1hcmdpbi1sZWZ0OiAycHg7XG59XG4ucGFnZS1jb250YWluZXIge1xuICBtYXJnaW4tdG9wOiA1cHg7XG4gIG1hcmdpbi1sZWZ0OiA1cHg7XG59XG4ucGFnZS1jb250ZW50IHtcbiAgbWFyZ2luLXRvcDogNXB4O1xuICBtYXJnaW4tbGVmdDogNXB4O1xufVxuLmZvcm0tY29udHJvbCB7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiBjYWxjKDIuMjVyZW0gKyAycHgpO1xuICBwYWRkaW5nOiAwLjQ1cmVtIDAuOXJlbTtcbiAgZm9udC1zaXplOiAwLjlyZW07XG4gIGZvbnQtd2VpZ2h0OiA0MDA7XG4gIGxpbmUtaGVpZ2h0OiAxLjU7XG4gIGNvbG9yOiAjNmM3NTdkO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICBiYWNrZ3JvdW5kLWNsaXA6IHBhZGRpbmctYm94O1xuICBib3JkZXI6IDFweCBzb2xpZCAjZGVlMmU2O1xuICBib3JkZXItcmFkaXVzOiAwLjI1cmVtO1xuICB0cmFuc2l0aW9uOiBib3JkZXItY29sb3IgMC4xNXMgZWFzZS1pbi1vdXQsIGJveC1zaGFkb3cgMC4xNXMgZWFzZS1pbi1vdXQ7XG59XG4uZm9ybS1jb250cm9sOmZvY3VzIHtcbiAgY29sb3I6ICM0OTUwNTc7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gIGJvcmRlci1jb2xvcjogI2MxYzlkMDtcbiAgb3V0bGluZTogMDtcbn1cbi5mb3JtLWNvbnRyb2wtcmlnaHQge1xuICBkaXNwbGF5OiBibG9jaztcbiAgd2lkdGg6IDc0JTtcbiAgZmxvYXQ6IGxlZnQ7XG4gIGhlaWdodDogY2FsYygyLjI1cmVtICsgMnB4KTtcbiAgcGFkZGluZzogMC40NXJlbSAwLjlyZW07XG4gIGZvbnQtc2l6ZTogMC45cmVtO1xuICBmb250LXdlaWdodDogNDAwO1xuICBsaW5lLWhlaWdodDogMS41O1xuICBjb2xvcjogIzZjNzU3ZDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgYmFja2dyb3VuZC1jbGlwOiBwYWRkaW5nLWJveDtcbiAgYm9yZGVyOiAxcHggc29saWQgI2RlZTJlNjtcbiAgYm9yZGVyLXJhZGl1czogMC4yNXJlbTtcbiAgdHJhbnNpdGlvbjogYm9yZGVyLWNvbG9yIDAuMTVzIGVhc2UtaW4tb3V0LCBib3gtc2hhZG93IDAuMTVzIGVhc2UtaW4tb3V0O1xufVxuLmZvcm0tY29udHJvbC1yaWdodDpmb2N1cyB7XG4gIGNvbG9yOiAjNDk1MDU3O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICBib3JkZXItY29sb3I6ICNjMWM5ZDA7XG4gIG91dGxpbmU6IDA7XG59XG4uZm9ybS1sYWJlbC1yaWdodCB7XG4gIHdpZHRoOiAyNSU7XG4gIGZsb2F0OiBsZWZ0O1xuICBtYXJnaW4tdG9wOiA1cHg7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cbi5mb3JtLWdyb3VwLXJpZ2h0IHtcbiAgbWluLWhlaWdodDogNDVweDtcbiAgbWF4LWhlaWdodDogMTAwcHg7XG4gIHBhZGRpbmc6IDFweDtcbn1cbi5idG4tc3VjY2VzcyB7XG4gIGNvbG9yOiAjZmZmO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMGFjZjk3O1xuICBib3JkZXItY29sb3I6ICMwYWNmOTc7XG59XG4uYnRuLXN1Y2Nlc3M6aG92ZXIge1xuICBib3gtc2hhZG93OiAwIDJweCA2cHggMCByZ2JhKDEwLCAyMDcsIDE1MSwgMC41KTtcbn1cbi5jYXJkIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBtaW4td2lkdGg6IDA7XG4gIHdvcmQtd3JhcDogYnJlYWstd29yZDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgYmFja2dyb3VuZC1jbGlwOiBpbml0aWFsO1xuICBib3JkZXI6IDFweCBzb2xpZCAjZWVmMmY3O1xuICBib3JkZXItcmFkaXVzOiAwLjI1cmVtO1xuICBtYXJnaW4tdG9wOiAzMCU7XG59XG4uY2FyZC1oZWFkZXIge1xuICBwYWRkaW5nOiAwLjc1cmVtIDEuNXJlbTtcbiAgbWFyZ2luLWJvdHRvbTogMDtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlZWYyZjc7XG4gIGJhY2tncm91bmQtY29sb3I6ICM3MjdjZjUgIWltcG9ydGFudDtcbiAgY29sb3I6IHdoaXRlO1xuICBoZWlnaHQ6IDYwcHg7XG59XG4iLCJAaW1wb3J0ICcuLi8uLi9jb21tb24ubGVzcyc7XG4uY2FyZCB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICBtaW4td2lkdGg6IDA7XG4gICAgd29yZC13cmFwOiBicmVhay13b3JkO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gICAgYmFja2dyb3VuZC1jbGlwOiBpbml0aWFsO1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICNlZWYyZjc7XG4gICAgYm9yZGVyLXJhZGl1czogLjI1cmVtO1xuICAgIG1hcmdpbi10b3A6IDMwJTtcbn1cbi5jYXJkLWhlYWRlcntcbiAgICBwYWRkaW5nOiAuNzVyZW0gMS41cmVtO1xuICAgIG1hcmdpbi1ib3R0b206IDA7XG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlZWYyZjc7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzcyN2NmNSFpbXBvcnRhbnQ7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIGhlaWdodDogNjBweDtcbn1cbiAiXX0= */"

/***/ }),

/***/ "./src/app/forgot-password/forgot-password.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/forgot-password/forgot-password.component.ts ***!
  \**************************************************************/
/*! exports provided: ForgotPasswordComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForgotPasswordComponent", function() { return ForgotPasswordComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ForgotPasswordComponent = /** @class */ (function () {
    function ForgotPasswordComponent() {
    }
    ForgotPasswordComponent.prototype.ngOnInit = function () {
    };
    ForgotPasswordComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-forgot-password',
            template: __webpack_require__(/*! raw-loader!./forgot-password.component.html */ "./node_modules/raw-loader/index.js!./src/app/forgot-password/forgot-password.component.html"),
            styles: [__webpack_require__(/*! ./forgot-password.component.less */ "./src/app/forgot-password/forgot-password.component.less")]
        }),
        __metadata("design:paramtypes", [])
    ], ForgotPasswordComponent);
    return ForgotPasswordComponent;
}());



/***/ }),

/***/ "./src/app/guards/auth.guard.ts":
/*!**************************************!*\
  !*** ./src/app/guards/auth.guard.ts ***!
  \**************************************/
/*! exports provided: AuthGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuard", function() { return AuthGuard; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_restservices_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/restservices/auth.service */ "./src/app/services/restservices/auth.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var AuthGuard = /** @class */ (function () {
    function AuthGuard(router, authService) {
        this.router = router;
        this.authService = authService;
    }
    AuthGuard.prototype.canActivate = function (next, state) {
        var currentUser = JSON.parse(sessionStorage.getItem('token'));
        if (currentUser) {
            // check if route is restricted by role
            if (next.data.roles && next.data.roles.indexOf(currentUser.role) === -1) {
                // role not authorised so redirect to home page
                this.router.navigate(['/']);
                return false;
            }
            // authorised so return true
            return true;
        }
        this.router.navigate(['/']);
        return this.authService.isLoggedIn();
    };
    AuthGuard.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] },
        { type: _services_restservices_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"] }
    ]; };
    AuthGuard = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"], _services_restservices_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]])
    ], AuthGuard);
    return AuthGuard;
}());



/***/ }),

/***/ "./src/app/login/login.component.less":
/*!********************************************!*\
  !*** ./src/app/login/login.component.less ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "*:focus {\n  outline: none;\n}\n.error-span {\n  font-family: \"Nunito\", sans-serif;\n  font-size: 12px;\n  color: #fa5c7c;\n}\n.popup-error {\n  margin-left: 25%;\n}\n.pageheading {\n  color: #333333;\n  font-family: \"Nunito\", sans-serif;\n  font-size: 20px;\n  margin-bottom: 10px;\n  margin-left: 2px;\n}\n.page-container {\n  margin-top: 5px;\n  margin-left: 5px;\n}\n.page-content {\n  margin-top: 5px;\n  margin-left: 5px;\n}\n.form-control {\n  display: block;\n  width: 100%;\n  height: calc(2.25rem + 2px);\n  padding: 0.45rem 0.9rem;\n  font-size: 0.9rem;\n  font-weight: 400;\n  line-height: 1.5;\n  color: #6c757d;\n  background-color: #fff;\n  background-clip: padding-box;\n  border: 1px solid #dee2e6;\n  border-radius: 0.25rem;\n  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;\n}\n.form-control:focus {\n  color: #495057;\n  background-color: #fff;\n  border-color: #c1c9d0;\n  outline: 0;\n}\n.form-control-right {\n  display: block;\n  width: 74%;\n  float: left;\n  height: calc(2.25rem + 2px);\n  padding: 0.45rem 0.9rem;\n  font-size: 0.9rem;\n  font-weight: 400;\n  line-height: 1.5;\n  color: #6c757d;\n  background-color: #fff;\n  background-clip: padding-box;\n  border: 1px solid #dee2e6;\n  border-radius: 0.25rem;\n  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;\n}\n.form-control-right:focus {\n  color: #495057;\n  background-color: #fff;\n  border-color: #c1c9d0;\n  outline: 0;\n}\n.form-label-right {\n  width: 25%;\n  float: left;\n  margin-top: 5px;\n  font-size: 14px;\n}\n.form-group-right {\n  min-height: 45px;\n  max-height: 100px;\n  padding: 1px;\n}\n.btn-success {\n  color: #fff;\n  background-color: #0acf97;\n  border-color: #0acf97;\n}\n.btn-success:hover {\n  box-shadow: 0 2px 6px 0 rgba(10, 207, 151, 0.5);\n}\n.card {\n  position: relative;\n  display: flex;\n  flex-direction: column;\n  min-width: 0;\n  word-wrap: break-word;\n  background-color: #fff;\n  background-clip: initial;\n  border: 1px solid #eef2f7;\n  border-radius: 0.25rem;\n  margin-top: 30%;\n}\n.card-header {\n  padding: 0.75rem 1.5rem;\n  margin-bottom: 0;\n  border-bottom: 1px solid #eef2f7;\n  background-color: #727cf5 !important;\n  color: white;\n  height: 60px;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9naW4vQzovVXNlcnMvTmV3L0RvY3VtZW50cy9HaXRIdWIvY2FyZS9zcmMvY29tbW9uLmxlc3MiLCJzcmMvYXBwL2xvZ2luL2xvZ2luLmNvbXBvbmVudC5sZXNzIiwic3JjL2FwcC9sb2dpbi9DOi9Vc2Vycy9OZXcvRG9jdW1lbnRzL0dpdEh1Yi9jYXJlL3NyYy9hcHAvbG9naW4vbG9naW4uY29tcG9uZW50Lmxlc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBb0NBO0VBQ0ksYUFBQTtBQ25DSjtBRHNDQTtFQUNFLGlDQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUNwQ0Y7QURzQ0E7RUFDRSxnQkFBQTtBQ3BDRjtBRDBFQTtFQUNFLGNBQUE7RUFDQSxpQ0FBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FDeEVGO0FENEVBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0FDMUVGO0FENEVBO0VBQ0MsZUFBQTtFQUNDLGdCQUFBO0FDMUVGO0FENkVBO0VBQ0ksY0FBQTtFQUNBLFdBQUE7RUFDQSwyQkFBQTtFQUNBLHVCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLHNCQUFBO0VBQ0EsNEJBQUE7RUFDQSx5QkFBQTtFQUNBLHNCQUFBO0VBQ0Esd0VBQUE7QUMzRUo7QUQ0RUk7RUFDQyxjQUFBO0VBQ0Qsc0JBQUE7RUFDQSxxQkFBQTtFQUNBLFVBQUE7QUMxRUo7QUQ4RUE7RUFDSSxjQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7RUFDQSwyQkFBQTtFQUNBLHVCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLHNCQUFBO0VBQ0EsNEJBQUE7RUFDQSx5QkFBQTtFQUNBLHNCQUFBO0VBQ0Esd0VBQUE7QUM1RUo7QUQ2RUk7RUFDQyxjQUFBO0VBQ0Qsc0JBQUE7RUFDQSxxQkFBQTtFQUNBLFVBQUE7QUMzRUo7QUQrRUE7RUFDRSxVQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0FDN0VGO0FEK0VBO0VBQ0ksZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7QUM3RUo7QURtRkE7RUFDSSxXQUFBO0VBQ0EseUJBQUE7RUFDQSxxQkFBQTtBQ2pGSjtBRGtGSTtFQUFRLCtDQUFBO0FDL0VaO0FDdEZBO0VBQ0ksa0JBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0VBQ0EscUJBQUE7RUFDQSxzQkFBQTtFQUNBLHdCQUFBO0VBQ0EseUJBQUE7RUFDQSxzQkFBQTtFQUNBLGVBQUE7QUR3Rko7QUN0RkE7RUFDSSx1QkFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0NBQUE7RUFDQSxvQ0FBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0FEd0ZKIiwiZmlsZSI6InNyYy9hcHAvbG9naW4vbG9naW4uY29tcG9uZW50Lmxlc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDb2xvciBWYXJpYWJsZXNcbkB3aGl0ZS1jb2xvcjogICAgICAgICNGRkZGRkY7XG5AYmxhY2stY29sb3I6ICAgICAgICAjMDAwMDAwO1xuQHJlZC1jb2xvcjpcdFx0XHQgICAgICNENTJCMUU7XG5AZ3JleTEtY29sb3I6ICAgICAgICAjRjZGNkY2Oy8vbGlnaHQgZ3JleVxuQGdyZXkyLWNvbG9yOiAgICAgICAgI0Q4REFEQTtcbkBncmV5My1jb2xvcjogICAgICAgICM3NDc2NzY7XG5AZ3JleTQtY29sb3I6ICAgICAgICAjMzMzMzMzOy8vIGRhcmsgZ3JleVxuQG9yYW5nZTEtY29sb3I6ICAgICAgI0Y5RDBBQjsgLy8gbGlnaHQgb3JhbmdlXG5Ab3JhbmdlMi1jb2xvcjogICAgICAjRjNBMTU3O1xuQG9yYW5nZTMtY29sb3I6ICAgICAgI0VENzAwMDsgLy8gZGFyayBvcmFuZ2VcbkB5ZWxsb3cxLWNvbG9yOiAgICAgICNGRkU5QkY7IC8vIGxpZ2h0IHllbGxvd1xuQHllbGxvdzItY29sb3I6ICAgICAgI0ZGRDM3RjsgXG5AeWVsbG93My1jb2xvcjogICAgICAjRkZCQzNEOyAvLyBkYXJrIHllbGxvd1xuQGdyZWVuMS1jb2xvcjogICAgICAgI0FCRTRCRjsgLy8gbGlnaHQgZ3JlZW5cbkBncmVlbjItY29sb3I6ICAgICAgICM1N0M4ODA7IFxuQGdyZWVuMy1jb2xvcjogICAgICAgIzAwQUMzRTsgLy8gZGFyayBncmVlblxuQGJsdWUtY29sb3I6ICAgICAgICAgI0FCRDhFRjsgLy8gbGlnaHQgYmx1ZVxuQGJsdWUyLWNvbG9yOiAgICAgICAgIzU3QjFERjsgXG5AYmx1ZTMtY29sb3I6ICAgICAgICAjMDA4OENFOyAvLyBkYXJrIGJsdWVcbi8vaGVhZGVyIGNvbG9yXG5AYmFja2dyb3VuZC1jb2xvcjogQHdoaXRlLWNvbG9yO1xuQGhlYWRlci1mb250LWNvbG9yOiBAYmxhY2stY29sb3I7XG5cblxuXG5AZm9udC1mYW1pbHkgOiAgXCJOdW5pdG9cIixzYW5zLXNlcmlmO1xuXG4vL2JvcmRlcnNcbkBib3JkZXJzLXN0eWxlOiAxcHggc29saWQgQGdyZXkyLWNvbG9yOyBcbkBib3JkZXItYm90dG9tOiBAYm9yZGVycy1zdHlsZTtcbkBib3JkZXItYm90dG9tLWhvdmVyOiAxcHggc29saWQgQHJlZC1jb2xvcjtcbkBoZWFkZXItbWVudS1zZWxlY3RlZDogMnB4IHNvbGlkIEByZWQtY29sb3I7XG5cblxuLy8gaW5wdXRib3hcbio6Zm9jdXMge1xuICAgIG91dGxpbmU6IG5vbmU7XG59XG5cbi5lcnJvci1zcGFue1xuICBmb250LWZhbWlseTogQGZvbnQtZmFtaWx5O1xuICBmb250LXNpemU6IDEycHg7XG4gIGNvbG9yOiAjZmE1YzdjO1xufVxuLnBvcHVwLWVycm9ye1xuICBtYXJnaW4tbGVmdDogMjUlO1xufVxuXG4uY29udGFpbmVyLWJvcmRlcigpIHtcblx0Ym9yZGVyOiBAYm9yZGVycy1zdHlsZTtcblx0Ym9yZGVyLXJhZGl1czo1cHg7XG59XG5cbi5idXR0b24oKXtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgICBjb2xvcjogIzZjNzU3ZDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgICAtd2Via2l0LXVzZXItc2VsZWN0OiBub25lO1xuICAgIC1tb3otdXNlci1zZWxlY3Q6IG5vbmU7XG4gICAgLW1zLXVzZXItc2VsZWN0OiBub25lO1xuICAgIHVzZXItc2VsZWN0OiBub25lO1xuICAgIGJhY2tncm91bmQtY29sb3I6IGluaXRpYWw7XG4gICAgYm9yZGVyOiAxcHggc29saWQgdHJhbnNwYXJlbnQ7XG4gICAgcGFkZGluZzogLjQ1cmVtIC45cmVtO1xuICAgIGZvbnQtc2l6ZTogLjlyZW07XG4gICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICBib3JkZXItcmFkaXVzOiAuMTVyZW07XG4gICAgdHJhbnNpdGlvbjogY29sb3IgLjE1cyBlYXNlLWluLW91dCxiYWNrZ3JvdW5kLWNvbG9yIC4xNXMgZWFzZS1pbi1vdXQsYm9yZGVyLWNvbG9yIC4xNXMgZWFzZS1pbi1vdXQsYm94LXNoYWRvdyAuMTVzIGVhc2UtaW4tb3V0O1xufVxuXG4vLyBCdXR0b24gY2xhc3Nlc1xuLmJ1dHRvbi1wcmltYXJ5KCl7XG4gIC5idXR0b24oKTtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzBhY2Y5NztcbiAgY29sb3I6IEB3aGl0ZS1jb2xvcjtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICAmOmhvdmVyIHtcbiAgICBib3gtc2hhZG93IDogMCAycHggNnB4IDAgcmdiYSgxMCwyMDcsMTUxLC41KTt9XG59XG5cblxuLnBhZ2VoZWFkaW5ne1xuICBjb2xvcjogQGdyZXk0LWNvbG9yO1xuICBmb250LWZhbWlseTogQGZvbnQtZmFtaWx5O1xuICBmb250LXNpemU6IDIwcHg7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIG1hcmdpbi1sZWZ0OiAycHg7XG5cbn1cblxuLnBhZ2UtY29udGFpbmVye1xuICBtYXJnaW4tdG9wOjVweDtcbiAgbWFyZ2luLWxlZnQ6NXB4OyBcbn1cbi5wYWdlLWNvbnRlbnR7XG4gbWFyZ2luLXRvcDo1cHg7XG4gIG1hcmdpbi1sZWZ0OjVweDsgIFxufVxuXG4uZm9ybS1jb250cm9sIHtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IGNhbGMoMi4yNXJlbSArIDJweCk7XG4gICAgcGFkZGluZzogLjQ1cmVtIC45cmVtO1xuICAgIGZvbnQtc2l6ZTogLjlyZW07XG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIGNvbG9yOiAjNmM3NTdkO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gICAgYmFja2dyb3VuZC1jbGlwOiBwYWRkaW5nLWJveDtcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZGVlMmU2O1xuICAgIGJvcmRlci1yYWRpdXM6IC4yNXJlbTtcbiAgICB0cmFuc2l0aW9uOiBib3JkZXItY29sb3IgLjE1cyBlYXNlLWluLW91dCxib3gtc2hhZG93IC4xNXMgZWFzZS1pbi1vdXQ7XG4gICAgJjpmb2N1c1xuICAgIHtjb2xvcjogIzQ5NTA1NztcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICAgIGJvcmRlci1jb2xvcjogI2MxYzlkMDtcbiAgICBvdXRsaW5lOiAwO1xuICB9O1xufVxuXG4uZm9ybS1jb250cm9sLXJpZ2h0IHtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICB3aWR0aDogNzQlO1xuICAgIGZsb2F0OiBsZWZ0O1xuICAgIGhlaWdodDogY2FsYygyLjI1cmVtICsgMnB4KTtcbiAgICBwYWRkaW5nOiAuNDVyZW0gLjlyZW07XG4gICAgZm9udC1zaXplOiAuOXJlbTtcbiAgICBmb250LXdlaWdodDogNDAwO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU7XG4gICAgY29sb3I6ICM2Yzc1N2Q7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgICBiYWNrZ3JvdW5kLWNsaXA6IHBhZGRpbmctYm94O1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICNkZWUyZTY7XG4gICAgYm9yZGVyLXJhZGl1czogLjI1cmVtO1xuICAgIHRyYW5zaXRpb246IGJvcmRlci1jb2xvciAuMTVzIGVhc2UtaW4tb3V0LGJveC1zaGFkb3cgLjE1cyBlYXNlLWluLW91dDtcbiAgICAmOmZvY3VzXG4gICAge2NvbG9yOiAjNDk1MDU3O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gICAgYm9yZGVyLWNvbG9yOiAjYzFjOWQwO1xuICAgIG91dGxpbmU6IDA7XG4gIH07XG59XG5cbi5mb3JtLWxhYmVsLXJpZ2h0e1xuICB3aWR0aDogMjUlO1xuICBmbG9hdDogbGVmdDtcbiAgbWFyZ2luLXRvcDogNXB4O1xuICBmb250LXNpemU6IDE0cHg7XG59XG4uZm9ybS1ncm91cC1yaWdodHtcbiAgICBtaW4taGVpZ2h0OiA0NXB4O1xuICAgIG1heC1oZWlnaHQ6IDEwMHB4O1xuICAgIHBhZGRpbmc6IDFweDtcbn1cblxuXG5cblxuLmJ0bi1zdWNjZXNzIHtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMGFjZjk3O1xuICAgIGJvcmRlci1jb2xvcjogIzBhY2Y5NztcbiAgICAmOmhvdmVye2JveC1zaGFkb3c6IDAgMnB4IDZweCAwIHJnYmEoMTAsMjA3LDE1MSwuNSk7XG59XG59IiwiKjpmb2N1cyB7XG4gIG91dGxpbmU6IG5vbmU7XG59XG4uZXJyb3Itc3BhbiB7XG4gIGZvbnQtZmFtaWx5OiBcIk51bml0b1wiLCBzYW5zLXNlcmlmO1xuICBmb250LXNpemU6IDEycHg7XG4gIGNvbG9yOiAjZmE1YzdjO1xufVxuLnBvcHVwLWVycm9yIHtcbiAgbWFyZ2luLWxlZnQ6IDI1JTtcbn1cbi5wYWdlaGVhZGluZyB7XG4gIGNvbG9yOiAjMzMzMzMzO1xuICBmb250LWZhbWlseTogXCJOdW5pdG9cIiwgc2Fucy1zZXJpZjtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICBtYXJnaW4tbGVmdDogMnB4O1xufVxuLnBhZ2UtY29udGFpbmVyIHtcbiAgbWFyZ2luLXRvcDogNXB4O1xuICBtYXJnaW4tbGVmdDogNXB4O1xufVxuLnBhZ2UtY29udGVudCB7XG4gIG1hcmdpbi10b3A6IDVweDtcbiAgbWFyZ2luLWxlZnQ6IDVweDtcbn1cbi5mb3JtLWNvbnRyb2wge1xuICBkaXNwbGF5OiBibG9jaztcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogY2FsYygyLjI1cmVtICsgMnB4KTtcbiAgcGFkZGluZzogMC40NXJlbSAwLjlyZW07XG4gIGZvbnQtc2l6ZTogMC45cmVtO1xuICBmb250LXdlaWdodDogNDAwO1xuICBsaW5lLWhlaWdodDogMS41O1xuICBjb2xvcjogIzZjNzU3ZDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgYmFja2dyb3VuZC1jbGlwOiBwYWRkaW5nLWJveDtcbiAgYm9yZGVyOiAxcHggc29saWQgI2RlZTJlNjtcbiAgYm9yZGVyLXJhZGl1czogMC4yNXJlbTtcbiAgdHJhbnNpdGlvbjogYm9yZGVyLWNvbG9yIDAuMTVzIGVhc2UtaW4tb3V0LCBib3gtc2hhZG93IDAuMTVzIGVhc2UtaW4tb3V0O1xufVxuLmZvcm0tY29udHJvbDpmb2N1cyB7XG4gIGNvbG9yOiAjNDk1MDU3O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICBib3JkZXItY29sb3I6ICNjMWM5ZDA7XG4gIG91dGxpbmU6IDA7XG59XG4uZm9ybS1jb250cm9sLXJpZ2h0IHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIHdpZHRoOiA3NCU7XG4gIGZsb2F0OiBsZWZ0O1xuICBoZWlnaHQ6IGNhbGMoMi4yNXJlbSArIDJweCk7XG4gIHBhZGRpbmc6IDAuNDVyZW0gMC45cmVtO1xuICBmb250LXNpemU6IDAuOXJlbTtcbiAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgY29sb3I6ICM2Yzc1N2Q7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gIGJhY2tncm91bmQtY2xpcDogcGFkZGluZy1ib3g7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNkZWUyZTY7XG4gIGJvcmRlci1yYWRpdXM6IDAuMjVyZW07XG4gIHRyYW5zaXRpb246IGJvcmRlci1jb2xvciAwLjE1cyBlYXNlLWluLW91dCwgYm94LXNoYWRvdyAwLjE1cyBlYXNlLWluLW91dDtcbn1cbi5mb3JtLWNvbnRyb2wtcmlnaHQ6Zm9jdXMge1xuICBjb2xvcjogIzQ5NTA1NztcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgYm9yZGVyLWNvbG9yOiAjYzFjOWQwO1xuICBvdXRsaW5lOiAwO1xufVxuLmZvcm0tbGFiZWwtcmlnaHQge1xuICB3aWR0aDogMjUlO1xuICBmbG9hdDogbGVmdDtcbiAgbWFyZ2luLXRvcDogNXB4O1xuICBmb250LXNpemU6IDE0cHg7XG59XG4uZm9ybS1ncm91cC1yaWdodCB7XG4gIG1pbi1oZWlnaHQ6IDQ1cHg7XG4gIG1heC1oZWlnaHQ6IDEwMHB4O1xuICBwYWRkaW5nOiAxcHg7XG59XG4uYnRuLXN1Y2Nlc3Mge1xuICBjb2xvcjogI2ZmZjtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzBhY2Y5NztcbiAgYm9yZGVyLWNvbG9yOiAjMGFjZjk3O1xufVxuLmJ0bi1zdWNjZXNzOmhvdmVyIHtcbiAgYm94LXNoYWRvdzogMCAycHggNnB4IDAgcmdiYSgxMCwgMjA3LCAxNTEsIDAuNSk7XG59XG4uY2FyZCB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgbWluLXdpZHRoOiAwO1xuICB3b3JkLXdyYXA6IGJyZWFrLXdvcmQ7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gIGJhY2tncm91bmQtY2xpcDogaW5pdGlhbDtcbiAgYm9yZGVyOiAxcHggc29saWQgI2VlZjJmNztcbiAgYm9yZGVyLXJhZGl1czogMC4yNXJlbTtcbiAgbWFyZ2luLXRvcDogMzAlO1xufVxuLmNhcmQtaGVhZGVyIHtcbiAgcGFkZGluZzogMC43NXJlbSAxLjVyZW07XG4gIG1hcmdpbi1ib3R0b206IDA7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZWVmMmY3O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjNzI3Y2Y1ICFpbXBvcnRhbnQ7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgaGVpZ2h0OiA2MHB4O1xufVxuIiwiQGltcG9ydCAnLi4vLi4vY29tbW9uLmxlc3MnO1xuLmNhcmQge1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgbWluLXdpZHRoOiAwO1xuICAgIHdvcmQtd3JhcDogYnJlYWstd29yZDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICAgIGJhY2tncm91bmQtY2xpcDogaW5pdGlhbDtcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZWVmMmY3O1xuICAgIGJvcmRlci1yYWRpdXM6IC4yNXJlbTtcbiAgICBtYXJnaW4tdG9wOiAzMCU7XG59XG4uY2FyZC1oZWFkZXJ7XG4gICAgcGFkZGluZzogLjc1cmVtIDEuNXJlbTtcbiAgICBtYXJnaW4tYm90dG9tOiAwO1xuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZWVmMmY3O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICM3MjdjZjUhaW1wb3J0YW50O1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBoZWlnaHQ6IDYwcHg7XG59XG4gICAgIl19 */"

/***/ }),

/***/ "./src/app/login/login.component.ts":
/*!******************************************!*\
  !*** ./src/app/login/login.component.ts ***!
  \******************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../services/auth.service */ "./src/app/services/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ngx-toastr */ "./node_modules/ngx-toastr/fesm5/ngx-toastr.js");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/fesm5/ngx-spinner.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var LoginComponent = /** @class */ (function () {
    function LoginComponent(spinner, toastr, formBuilder, authService, router) {
        this.spinner = spinner;
        this.toastr = toastr;
        this.formBuilder = formBuilder;
        this.authService = authService;
        this.router = router;
        this.isSubmitted = false;
        this.isDisabled = false;
    }
    Object.defineProperty(LoginComponent.prototype, "formControls", {
        get: function () { return this.loginForm.controls; },
        enumerable: true,
        configurable: true
    });
    LoginComponent.prototype.ngOnInit = function () {
        this.loginForm = this.formBuilder.group({
            user_name: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].email]],
            password: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required],
            remember_me: false
        });
    };
    LoginComponent.prototype.login = function () {
        var _this = this;
        this.isSubmitted = true;
        this.isDisabled = true;
        if (this.loginForm.invalid) {
            this.isDisabled = false;
            return;
        }
        this.spinner.show();
        var user = {
            email: this.loginForm.value.user_name.toLowerCase(),
            password: this.loginForm.value.password,
        };
        this.authService.login(user).subscribe(function (response) {
            _this.spinner.hide();
            _this.toastr.success('Logged in successfully');
            var res = response;
            console.log(response.headers);
            //sessionStorage.setItem('token', JSON.stringify(response.headers)); 
            if (res.roles[0].name == 'Carer') {
                sessionStorage.setItem('token', JSON.stringify('Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxIiwic2NwIjoidXNlciIsImF1ZCI6bnVsbCwiaWF0IjoxNjE2NTEyMzM1LCJleHAiOjE2MTcxMTcxMzUsImp0aSI6ImIyNDcxZmYwLTA0OTgtNDBiMi1iOTEwLTlkNTg3OGQ2YTM0MiJ9.ohWKJz2BsQ15V0tkLZMrN88rABYlkg24AMHlMQwx86U'));
                sessionStorage.setItem('role', JSON.stringify(('carer')));
                _this.router.navigateByUrl('/customer/appointment');
            }
            else {
                sessionStorage.setItem('token', JSON.stringify('Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxIiwic2NwIjoidXNlciIsImF1ZCI6bnVsbCwiaWF0IjoxNjE2NTEyMzM1LCJleHAiOjE2MTcxMTcxMzUsImp0aSI6ImIyNDcxZmYwLTA0OTgtNDBiMi1iOTEwLTlkNTg3OGQ2YTM0MiJ9.ohWKJz2BsQ15V0tkLZMrN88rABYlkg24AMHlMQwx86U'));
                sessionStorage.setItem('role', JSON.stringify(('admin')));
                _this.router.navigateByUrl('/customer/dashboard');
            }
            if (_this.loginForm.value.remember_me == true) {
                localStorage.setItem('remember_me', 'true');
                localStorage.setItem('user_name', _this.loginForm.value.user_name);
                localStorage.setItem('password', _this.loginForm.value.password);
            }
            else {
                localStorage.setItem('remember_me', 'false');
                localStorage.removeItem('user_name');
                localStorage.removeItem('password');
            }
        }, function (error) {
            _this.spinner.hide();
            _this.toastr.error(error.error.error);
            _this.isSubmitted = false;
            _this.isDisabled = false;
        });
    };
    LoginComponent.ctorParameters = function () { return [
        { type: ngx_spinner__WEBPACK_IMPORTED_MODULE_5__["NgxSpinnerService"] },
        { type: ngx_toastr__WEBPACK_IMPORTED_MODULE_4__["ToastrService"] },
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"] },
        { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
    ]; };
    LoginComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-login',
            template: __webpack_require__(/*! raw-loader!./login.component.html */ "./node_modules/raw-loader/index.js!./src/app/login/login.component.html"),
            styles: [__webpack_require__(/*! ./login.component.less */ "./src/app/login/login.component.less")]
        }),
        __metadata("design:paramtypes", [ngx_spinner__WEBPACK_IMPORTED_MODULE_5__["NgxSpinnerService"], ngx_toastr__WEBPACK_IMPORTED_MODULE_4__["ToastrService"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"], _services_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], LoginComponent);
    return LoginComponent;
}());



/***/ }),

/***/ "./src/app/services/auth.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _interceptor_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./interceptor.service */ "./src/app/services/interceptor.service.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var AuthService = /** @class */ (function () {
    function AuthService(http, interceptor) {
        this.http = http;
        this.interceptor = interceptor;
        this.api_url = _environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].url;
        this.headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({ 'Content-Type': 'application/json' });
        this.httpOptions = { headers: this.headers };
    }
    AuthService.prototype.login = function (params) {
        var param = {
            "user": params
        };
        //let url = 'https://reqres.in/api/login';
        //return this.interceptor.createData(url,params); 
        var api_url = 'http://freshcare.herokuapp.com/users/sign_in/';
        return this.interceptor.createData(api_url, param);
    };
    AuthService.prototype.getUsers = function () {
        var url = this.api_url + '/api/users?page=2';
        return this.interceptor.retrieveData(url);
    };
    AuthService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
        { type: _interceptor_service__WEBPACK_IMPORTED_MODULE_2__["InterceptorService"] }
    ]; };
    AuthService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"], _interceptor_service__WEBPACK_IMPORTED_MODULE_2__["InterceptorService"]])
    ], AuthService);
    return AuthService;
}());



/***/ }),

/***/ "./src/app/services/interceptor.service.ts":
/*!*************************************************!*\
  !*** ./src/app/services/interceptor.service.ts ***!
  \*************************************************/
/*! exports provided: InterceptorService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InterceptorService", function() { return InterceptorService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var obj;
var InterceptorService = /** @class */ (function () {
    function InterceptorService(router, http) {
        this.router = router;
        this.http = http;
        this.headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' });
        this.httpOptions = { headers: this.headers };
        obj = this;
    }
    InterceptorService.prototype.initHeaders = function () {
        this.headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' });
        this.httpOptions = { headers: this.headers };
    };
    InterceptorService.prototype.retrieveData = function (url) {
        this.initHeaders();
        // return this.http.get<any>(url, this.httpOptions)
        //   .pipe(timeout(this.timeoutsec),map(response => {     
        //     return response;
        // }));
        return this.http.get(url, this.httpOptions)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["catchError"])(this.handleError));
    };
    InterceptorService.prototype.createData = function (url, params) {
        this.initHeaders();
        // return this.http.post<any>(url, JSON.stringify(params),this.httpOptions)
        // .pipe(timeout(this.timeoutsec),map(response => {     
        //   return response;
        // }))
        return this.http.post(url, JSON.stringify(params), this.httpOptions)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["catchError"])(this.handleError));
    };
    InterceptorService.prototype.updateData = function (url, params) {
        this.initHeaders();
        // return this.http.put<any>(url, JSON.stringify(params),this.httpOptions)
        // .pipe(timeout(this.timeoutsec),map(response => {     
        //   return response;
        // }))
        return this.http.put(url, JSON.stringify(params), this.httpOptions)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["catchError"])(this.handleError));
    };
    InterceptorService.prototype.deleteData = function (url) {
        this.initHeaders();
        // return this.http.put<any>(url, this.httpOptions)
        // .pipe(timeout(this.timeoutsec),map(response => {     
        //   return response;
        // }))
        return this.http.delete(url, this.httpOptions)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["catchError"])(this.handleError));
    };
    InterceptorService.prototype.handleError = function (error) {
        if (error.error instanceof ErrorEvent) {
            // A client-side or network error occurred. Handle it accordingly.
            // console.error('An error occurred:', error.error.message);
        }
        else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong,
            // console.error(
            //   `Backend returned code ${error.status}, ` +
            //   `body was: ${error.error}`);
            obj.logoutIfExpired(error.error);
        }
        // return an observable with a user-facing error message
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["throwError"])(error);
    };
    ;
    InterceptorService.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }
    ]; };
    InterceptorService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], InterceptorService);
    return InterceptorService;
}());



/***/ }),

/***/ "./src/app/services/restservices/auth.service.ts":
/*!*******************************************************!*\
  !*** ./src/app/services/restservices/auth.service.ts ***!
  \*******************************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _interceptor_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./interceptor.service */ "./src/app/services/restservices/interceptor.service.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var AuthService = /** @class */ (function () {
    function AuthService(http, interceptor) {
        this.http = http;
        this.interceptor = interceptor;
        this.api_url = _environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].url;
    }
    AuthService.prototype.login = function (params) {
        var url = this.api_url + '/login';
        return this.interceptor.createData(url, params);
    };
    AuthService.prototype.isLoggedIn = function () {
        return sessionStorage.getItem('CURRENT_USER') !== null;
    };
    AuthService.prototype.logout = function () {
        sessionStorage.clear();
        return true;
    };
    AuthService.prototype.getUsers = function () {
        var url = this.api_url + '/agents';
        return this.interceptor.retrieveData(url);
    };
    AuthService.prototype.getClients = function () {
        var url = this.api_url + '/clients';
        return this.interceptor.retrieveData(url);
    };
    AuthService.prototype.getDairy = function () {
        var url = this.api_url + '/feedbacks';
        return this.interceptor.retrieveData(url);
    };
    AuthService.prototype.getCarerAppointments = function () {
        var url = this.api_url + '/appointments/carer';
        return this.interceptor.retrieveData(url);
    };
    AuthService.prototype.checkout = function (params, id) {
        var url = this.api_url + '/appointments/' + id + '/close_appointment';
        return this.interceptor.createData(url, params);
    };
    AuthService.prototype.checkIn = function (app_id, params) {
        var url = this.api_url + '/appointments/' + app_id + '/update_progress';
        return this.interceptor.createData(url, params);
    };
    AuthService.prototype.getAppointments = function () {
        var url = this.api_url + '/appointments';
        return this.interceptor.retrieveData(url);
    };
    AuthService.prototype.getGroups = function () {
        var url = this.api_url + '/groups';
        return this.interceptor.retrieveData(url);
    };
    AuthService.prototype.createUser = function (params) {
        var url = this.api_url + '/agents';
        return this.interceptor.createData(url, params);
    };
    AuthService.prototype.createGroups = function (params) {
        var url = this.api_url + '/groups';
        return this.interceptor.createData(url, params);
    };
    AuthService.prototype.createClients = function (params) {
        var url = this.api_url + '/clients';
        return this.interceptor.createData(url, params);
    };
    AuthService.prototype.createAppointments = function (params) {
        var url = this.api_url + '/appointments';
        return this.interceptor.createData(url, params);
    };
    AuthService.prototype.createDairy = function (params) {
        var url = this.api_url + '/feedbacks';
        return this.interceptor.createData(url, params);
    };
    AuthService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
        { type: _interceptor_service__WEBPACK_IMPORTED_MODULE_2__["InterceptorService"] }
    ]; };
    AuthService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"], _interceptor_service__WEBPACK_IMPORTED_MODULE_2__["InterceptorService"]])
    ], AuthService);
    return AuthService;
}());



/***/ }),

/***/ "./src/app/services/restservices/interceptor.service.ts":
/*!**************************************************************!*\
  !*** ./src/app/services/restservices/interceptor.service.ts ***!
  \**************************************************************/
/*! exports provided: InterceptorService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InterceptorService", function() { return InterceptorService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var obj;
var InterceptorService = /** @class */ (function () {
    function InterceptorService(router, http) {
        this.router = router;
        this.http = http;
        this.auth_key = JSON.parse(sessionStorage.getItem('token'));
        this.headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json', 'auth_key': this.auth_key });
        this.httpOptions = { headers: this.headers };
        obj = this;
    }
    InterceptorService.prototype.initHeaders = function () {
        this.auth_key = JSON.parse(sessionStorage.getItem('token'));
        this.headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json', 'Authorization': this.auth_key });
        this.httpOptions = { headers: this.headers };
    };
    InterceptorService.prototype.retrieveData = function (url) {
        this.initHeaders();
        // return this.http.get<any>(url, this.httpOptions)
        //   .pipe(timeout(this.timeoutsec),map(response => {     
        //     return response;
        // }));
        return this.http.get(url, this.httpOptions)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["catchError"])(this.handleError));
    };
    InterceptorService.prototype.createData = function (url, params) {
        this.initHeaders();
        // return this.http.post<any>(url, JSON.stringify(params),this.httpOptions)
        // .pipe(timeout(this.timeoutsec),map(response => {     
        //   return response;
        // }))
        return this.http.post(url, JSON.stringify(params), this.httpOptions)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["catchError"])(this.handleError));
    };
    InterceptorService.prototype.updateData = function (url, params) {
        this.initHeaders();
        // return this.http.put<any>(url, JSON.stringify(params),this.httpOptions)
        // .pipe(timeout(this.timeoutsec),map(response => {     
        //   return response;
        // }))
        return this.http.put(url, JSON.stringify(params), this.httpOptions)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["catchError"])(this.handleError));
    };
    InterceptorService.prototype.deleteData = function (url) {
        this.initHeaders();
        // return this.http.put<any>(url, this.httpOptions)
        // .pipe(timeout(this.timeoutsec),map(response => {     
        //   return response;
        // }))
        return this.http.delete(url, this.httpOptions)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["catchError"])(this.handleError));
    };
    InterceptorService.prototype.handleError = function (error) {
        if (error.error instanceof ErrorEvent) {
            // A client-side or network error occurred. Handle it accordingly.
            // console.error('An error occurred:', error.error.message);
        }
        else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong,
            // console.error(
            //   `Backend returned code ${error.status}, ` +
            //   `body was: ${error.error}`);
            // obj.logoutIfExpired(error.error) 
        }
        // return an observable with a user-facing error message
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["throwError"])(error);
    };
    ;
    InterceptorService.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }
    ]; };
    InterceptorService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], InterceptorService);
    return InterceptorService;
}());



/***/ }),

/***/ "./src/app/shared-components/calender/calendar.component.less":
/*!********************************************************************!*\
  !*** ./src/app/shared-components/calender/calendar.component.less ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "h3 {\n  margin: 0 0 10px;\n}\npre {\n  background-color: #f5f5f5;\n  padding: 15px;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkLWNvbXBvbmVudHMvY2FsZW5kZXIvQzovVXNlcnMvTmV3L0RvY3VtZW50cy9HaXRIdWIvY2FyZS9zcmMvYXBwL3NoYXJlZC1jb21wb25lbnRzL2NhbGVuZGVyL2NhbGVuZGFyLmNvbXBvbmVudC5sZXNzIiwic3JjL2FwcC9zaGFyZWQtY29tcG9uZW50cy9jYWxlbmRlci9jYWxlbmRhci5jb21wb25lbnQubGVzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFBO0FDQ0Y7QURFQTtFQUNFLHlCQUFBO0VBQ0EsYUFBQTtBQ0FGIiwiZmlsZSI6InNyYy9hcHAvc2hhcmVkLWNvbXBvbmVudHMvY2FsZW5kZXIvY2FsZW5kYXIuY29tcG9uZW50Lmxlc3MiLCJzb3VyY2VzQ29udGVudCI6WyJoMyB7XG4gIG1hcmdpbjogMCAwIDEwcHg7XG59XG5cbnByZSB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmNWY1ZjU7XG4gIHBhZGRpbmc6IDE1cHg7XG59IiwiaDMge1xuICBtYXJnaW46IDAgMCAxMHB4O1xufVxucHJlIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZjVmNTtcbiAgcGFkZGluZzogMTVweDtcbn1cbiJdfQ== */"

/***/ }),

/***/ "./src/app/shared-components/calender/calendar.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/shared-components/calender/calendar.component.ts ***!
  \******************************************************************/
/*! exports provided: CalendarComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CalendarComponent", function() { return CalendarComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var CalendarComponent = /** @class */ (function () {
    function CalendarComponent() {
    }
    CalendarComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-calendar',
            changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectionStrategy"].OnPush,
            template: __webpack_require__(/*! raw-loader!./calendar.component.html */ "./node_modules/raw-loader/index.js!./src/app/shared-components/calender/calendar.component.html"),
            styles: [__webpack_require__(/*! ./calendar.component.less */ "./src/app/shared-components/calender/calendar.component.less")]
        }),
        __metadata("design:paramtypes", [])
    ], CalendarComponent);
    return CalendarComponent;
}());



/***/ }),

/***/ "./src/app/shared-components/child/child.component.less":
/*!**************************************************************!*\
  !*** ./src/app/shared-components/child/child.component.less ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC1jb21wb25lbnRzL2NoaWxkL2NoaWxkLmNvbXBvbmVudC5sZXNzIn0= */"

/***/ }),

/***/ "./src/app/shared-components/child/child.component.ts":
/*!************************************************************!*\
  !*** ./src/app/shared-components/child/child.component.ts ***!
  \************************************************************/
/*! exports provided: ChildComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChildComponent", function() { return ChildComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ChildComponent = /** @class */ (function () {
    function ChildComponent() {
    }
    ChildComponent.prototype.ngOnInit = function () {
    };
    ChildComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-child',
            template: __webpack_require__(/*! raw-loader!./child.component.html */ "./node_modules/raw-loader/index.js!./src/app/shared-components/child/child.component.html"),
            styles: [__webpack_require__(/*! ./child.component.less */ "./src/app/shared-components/child/child.component.less")]
        }),
        __metadata("design:paramtypes", [])
    ], ChildComponent);
    return ChildComponent;
}());



/***/ }),

/***/ "./src/app/shared-components/profile/profile.component.less":
/*!******************************************************************!*\
  !*** ./src/app/shared-components/profile/profile.component.less ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "h3 {\n  margin: 0 0 10px;\n}\npre {\n  background-color: #f5f5f5;\n  padding: 15px;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkLWNvbXBvbmVudHMvcHJvZmlsZS9DOi9Vc2Vycy9OZXcvRG9jdW1lbnRzL0dpdEh1Yi9jYXJlL3NyYy9hcHAvc2hhcmVkLWNvbXBvbmVudHMvcHJvZmlsZS9wcm9maWxlLmNvbXBvbmVudC5sZXNzIiwic3JjL2FwcC9zaGFyZWQtY29tcG9uZW50cy9wcm9maWxlL3Byb2ZpbGUuY29tcG9uZW50Lmxlc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxnQkFBQTtBQ0NGO0FERUE7RUFDRSx5QkFBQTtFQUNBLGFBQUE7QUNBRiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC1jb21wb25lbnRzL3Byb2ZpbGUvcHJvZmlsZS5jb21wb25lbnQubGVzcyIsInNvdXJjZXNDb250ZW50IjpbImgzIHtcbiAgbWFyZ2luOiAwIDAgMTBweDtcbn1cblxucHJlIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZjVmNTtcbiAgcGFkZGluZzogMTVweDtcbn0iLCJoMyB7XG4gIG1hcmdpbjogMCAwIDEwcHg7XG59XG5wcmUge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjVmNWY1O1xuICBwYWRkaW5nOiAxNXB4O1xufVxuIl19 */"

/***/ }),

/***/ "./src/app/shared-components/profile/profile.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/shared-components/profile/profile.component.ts ***!
  \****************************************************************/
/*! exports provided: ProfileComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfileComponent", function() { return ProfileComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ProfileComponent = /** @class */ (function () {
    function ProfileComponent() {
    }
    ProfileComponent.prototype.ngOnInit = function () {
    };
    ProfileComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-profile',
            template: __webpack_require__(/*! raw-loader!./profile.component.html */ "./node_modules/raw-loader/index.js!./src/app/shared-components/profile/profile.component.html"),
            styles: [__webpack_require__(/*! ./profile.component.less */ "./src/app/shared-components/profile/profile.component.less")]
        }),
        __metadata("design:paramtypes", [])
    ], ProfileComponent);
    return ProfileComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false,
    url: 'https://freshcare.herokuapp.com'
};
/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\New\Documents\GitHub\care\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map